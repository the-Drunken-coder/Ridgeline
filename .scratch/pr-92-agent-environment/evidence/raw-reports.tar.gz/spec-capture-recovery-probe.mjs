import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, symlinkSync, rmSync, existsSync, cpSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const { claimBrowserRun } = await import(pathToFileURL(process.argv[2]).href);
const reports = [];
process.env.RIDGELINE_BROWSER_MIN_FREE_BYTES = '0';
for (const protection of ['nested-symlink', 'nested-dangling', 'root-symlink', 'tracked']) {
  const root = mkdtempSync(join(tmpdir(), 'ridgeline-spec-capture-recovery-'));
  try {
    assert.equal(spawnSync('git', ['init', '-q'], { cwd: root }).status, 0);
    writeFileSync(join(root, '.gitignore'), '.artifacts/\n');
    const external = join(root, 'external'); mkdirSync(external);
    writeFileSync(join(external, 'report'), 'external producer bytes');
    const owner = claimBrowserRun(root, 'packaged'); owner.capture();
    const output = join(root, '.artifacts/playwright');
    if (protection === 'root-symlink') symlinkSync(external, output);
    else {
      mkdirSync(output);
      writeFileSync(join(output, 'report'), 'failure producer bytes');
      if (protection === 'nested-symlink') symlinkSync(external, join(output, 'protected'));
      if (protection === 'nested-dangling') symlinkSync(join(external, 'missing'), join(output, 'protected'));
      if (protection === 'tracked') assert.equal(spawnSync('git', ['add', '-f', '.artifacts/playwright/report'], { cwd: root }).status, 0);
    }
    const producer = readFileSync(join(output, 'report'), 'utf8');
    assert.throws(() => owner.finish(true), /Refusing to retain protected browser output/);
    assert.equal(existsSync(join(root, '.artifacts/browser-run.lock')), true);
    assert.equal(existsSync(join(owner.directory, '.pin')), true);
    assert.equal(JSON.parse(readFileSync(join(owner.directory, '.browser-run.json'), 'utf8')).status, 'running');
    assert.equal(readFileSync(join(output, 'report'), 'utf8'), producer);
    assert.throws(() => claimBrowserRun(root, 'packaged'));
    if (protection === 'root-symlink') { rmSync(output); cpSync(external, output, { recursive: true }); }
    else if (protection === 'tracked') assert.equal(spawnSync('git', ['rm', '--cached', '--', '.artifacts/playwright/report'], { cwd: root }).status, 0);
    else rmSync(join(output, 'protected'));
    owner.finish(true);
    assert.equal(existsSync(join(root, '.artifacts/browser-run.lock')), false);
    assert.equal(readFileSync(join(owner.directory, 'playwright/report'), 'utf8'), producer);
    const completed = JSON.parse(readFileSync(join(owner.directory, '.browser-run.json'), 'utf8'));
    assert.equal(completed.status, 'failed');
    const next = claimBrowserRun(root, 'packaged'); next.finish();
    assert.equal(readFileSync(join(owner.directory, 'playwright/report'), 'utf8'), producer);
    assert.equal(readFileSync(join(external, 'report'), 'utf8'), 'external producer bytes');
    reports.push({ protection, refused: true, lockRetained: true, nextClaimBlocked: true, retryCaptured: true, nextClaimRecovered: true, externalPreserved: true });
  } finally { rmSync(root, { recursive: true, force: true }); }
}
const result = { testedModule: process.argv[2], reports };
writeFileSync(process.argv[3], JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
