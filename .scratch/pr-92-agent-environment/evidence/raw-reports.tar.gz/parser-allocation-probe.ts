import assert from 'node:assert/strict';
import { parseGlb as beforeFix } from './parser-pre-fix.ts';
import { parseGlb } from '/tmp/ridgeline-93-parser-review/src/model-glb.ts';
import { encodeGlb } from '/tmp/ridgeline-93-parser-review/tests/model-fixtures.ts';

const bytes = encodeGlb({
  asset: { version: '2.0' }, buffers: [{ byteLength: 4 }],
  accessors: [{ componentType: 5126, count: 1_000_000_000, type: 'VEC3' }],
  meshes: [{ primitives: [{ attributes: { POSITION: 0 } }] }],
  nodes: [{ mesh: 0 }], scenes: [{ nodes: [0] }], scene: 0,
}, new Uint8Array(4));
const NativeArray = globalThis.Array;
const requests: number[] = [];
const intercepted = new Error('PROBE_INTERCEPTED_RESOURCE_REQUEST');
globalThis.Array = new Proxy(NativeArray, {
  construct(target, args, newTarget) {
    if (args.length === 1 && typeof args[0] === 'number' && args[0] > 100_000) {
      requests.push(args[0]);
      throw intercepted;
    }
    return Reflect.construct(target, args, newTarget);
  },
});
try {
  assert.throws(() => beforeFix(bytes), error => error === intercepted);
  assert.deepEqual(requests, [3_000_000_000]);
  console.log(JSON.stringify({ revision: 'd32e359e7fe4c7305d8793469e77151873eb8c49', glbBytes: bytes.byteLength,
    requestedArrayElements: requests[0], allocated: false }));
  requests.length = 0;
  assert.throws(() => parseGlb(bytes), { message: 'GLB_INVALID_ACCESSOR_COUNT' });
  assert.deepEqual(requests, []);
  console.log(JSON.stringify({ revision: '049c6bfad689055e8d26f14c0f479add924846cd', glbBytes: bytes.byteLength,
    rejection: 'GLB_INVALID_ACCESSOR_COUNT', unsafeResourceRequests: requests.length }));
} finally {
  globalThis.Array = NativeArray;
}
