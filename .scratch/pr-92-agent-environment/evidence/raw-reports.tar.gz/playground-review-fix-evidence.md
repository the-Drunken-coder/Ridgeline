# Playground cancellation and absence fixture follow-up

Recorded 2026-10-05 17:31 UTC. Root owns integrated verification #101; root merge remained on explicit hold during this work.

Reviewed baseline: `ee49a4b4b6df0526b06a2576b50e39307a8c57ae`. Scoped implementation commit: `361af95d341c441e6d7598626d7bc5c51a62fcb7`. Worktree `/tmp/ridgeline-93-review-fixes`, branch `implement/93-review-fixes`. Root integration `83abbd8315e9121fce9c2940ad6623e614709f2a` remained unchanged and was already merged into the owned branch. No PR, push, tracker write, root edit, or unchanged hosted retry was performed.

## Existing hosted evidence and limits

[Hosted run 37345459646](https://github.com/the-Drunken-coder/Ridgeline/actions/runs/37345459646), on revision `83abbd8`, reported the main model pixel/input workflow passed in 7.4 minutes at 17:10:57.099Z. The delayed/absent case failed in 10.1 minutes at 17:21:34.509Z. Leaving the model example cancelled pending fetches successfully in 1.3 minutes at 17:22:54.595Z. The job was cancelled at 17:23:02.441Z while the next case was active.

The producer log is `.artifacts/issue-93/hosted-first-playground.log` in the root checkout. Blob upload ran after cancellation, but reported no files. The separate screenshot/trace upload had `if: failure()` and did not run after cancellation. The failed case's detailed error, screenshot, and trace are unavailable. These timings establish failure and the 20-minute job cutoff. They do not establish which interaction failed or prove that repeated sample removal caused it. Root separately completed unchanged local full validation at `83abbd8` with all six playground tests passing.

## Lean change

The delayed/absent fixture previously selected and removed eight samples separately. It now selects the existing Empty map UI scenario once, checks the model panel is hidden and feature count is zero, then retains the same screenshot body criterion and 3-second absent assertion with actual successful pixel observations. The application destroys its model consumer and clears features through the existing viewport workflow, keeps the actual map canvas, and adds no samples for Empty map. Deterministic background pixels do not meet the teal filled-body criterion.

Delayed opacity restoration, multiple observations before readiness, the criterion of more than 30 filled neighbors, coordinate conversion, and the real model click remain intact. The existing main case still exercises sample removal and model registration/appearance/selection ownership. The per-test 600000 ms, render 120000 ms, setup 120000 ms, action behavior, and absent 3000 ms deadlines were not increased. Browser retries remain disabled.

The playground job now allows 35 minutes for the existing 30-minute child runner plus setup/upload margin. Its retained screenshot/trace upload uses `always()` and a nonempty `hashFiles` result for the existing output directory. This config permits output capture after cancellation when files exist. GitHub documents that `always()` remains true on cancellation and unmatched `hashFiles` returns an empty string: [expression semantics](https://docs.github.com/en/actions/reference/workflows-and-actions/expressions). This workflow change has not yet been verified in a hosted cancellation run; no artifact availability is claimed for the earlier failed run.

## Executed checks and source pin

The production playground check exercised revision `ee49a4b` with only these three scoped files modified, immediately before committing the identical source bytes to `361af95`. Those inputs are pinned below. It used standard port 5175 after root released it, no alternate config or port patch. Port 5175 was released after completion.

- `node scripts/test-browser-app.mjs playground --grep 'model pixel readiness waits for delayed screenshots and rejects an absent model'`: passed 1 test in 1.9 minutes, against the production package-export playground build. Delayed visible readiness, real picking input, empty-scenario transition, no-filled-body screenshot settlement, and bounded absence rejection all executed.
- `node --test scripts/validation.test.mjs`: passed 6 executable gate/report checks.
- `pnpm check`: passed before commit; final check at commit `361af95` is recorded in the same check producer log.
- Python YAML parse accepted the updated workflow and reported the 35-minute budget and guarded cancellation upload expression. This is syntax inspection, not execution of GitHub Actions.
- `git diff --check ee49a4b4b6df0526b06a2576b50e39307a8c57ae HEAD`: passed at `361af95`.

Owned committed source bytes, identical to exercised files:

- `tests/playground/model-example.spec.ts`: `d885e6b22987c232971f1645a8aeee663482bbec761d9ec63ff18a5ae8122a67`
- `.github/workflows/validation.yml`: `c818c4b11c35cb3d247a201e9a520868629d2b3448e5cd45e524b3b4c7dc960e`
- `docs/ci-validation.md`: `75818cd2d481381cebe254d8c94a580c964fc3a96871d5cba6818f4a62068b33`

Producer logs and SHA256:

- `/tmp/ridgeline-93-context/playground-review-fix-targeted.stdout.log`: `81f37b5f14074164f215c29b207c1907fffacff96780f038e0aa347c3ff854ca`
- `/tmp/ridgeline-93-context/playground-review-fix-validation.stdout.log`: `f63497ac1f5a3f5052840cd4ee1810350c03bfa1c064ebc3305ae64735351268`
- `/tmp/ridgeline-93-context/playground-review-fix-check.stdout.log`: `abd6b847b90a04c89ed0eefc5452eb314d77342815c044bf308da9b9129073c6`

Combined clean-source full validation and hosted verification of `361af95` remain root responsibilities. Existing hosted `ee49a4b` run 37347499718 uses the earlier fixture/workflow and cannot verify this follow-up. The historical unexplained culling frame and target-hardware acceptance remain separate limits.
