import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, copyFileSync, readdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, delimiter } from 'node:path';
import { spawnSync } from 'node:child_process';

const root = mkdtempSync(join(tmpdir(), 'ridgeline-spec-empty-argument-'));
try {
  assert.equal(spawnSync('git', ['init', '-q'], { cwd: root }).status, 0);
  writeFileSync(join(root, '.gitignore'), '.artifacts/\n');
  mkdirSync(join(root, 'scripts')); mkdirSync(join(root, 'bin'));
  for (const script of ['test-browser.mjs', 'browser-resources.mjs']) copyFileSync(join(process.argv[2], 'scripts', script), join(root, 'scripts', script));
  writeFileSync(join(root, 'bin/pnpm'), `#!/usr/bin/env node
const fs = require('node:fs'); const path = require('node:path');
if (process.argv.includes('scripts/prepare-consumer.mjs')) fs.mkdirSync(path.join(process.env.FIXTURE_ROOT, '.artifacts/consumer'), { recursive: true });
if (process.argv.includes('playwright')) {
  fs.mkdirSync(path.join(process.env.FIXTURE_ROOT, '.artifacts/playwright'), { recursive: true });
  fs.writeFileSync(path.join(process.env.FIXTURE_ROOT, '.artifacts/playwright/report'), process.env.FIXTURE_REPORT);
}
`, { mode: 0o755 });
  const statuses = [];
  for (let index = 0; index < 6; index++) {
    const result = spawnSync(process.execPath, [join(root, 'scripts/test-browser.mjs'), '--', '--grep', ''], {
      cwd: root, encoding: 'utf8', env: { ...process.env, FIXTURE_ROOT: root, FIXTURE_REPORT: `producer ${index}`,
        PATH: join(root, 'bin') + delimiter + process.env.PATH, RIDGELINE_BROWSER_MIN_FREE_BYTES: '0' },
    });
    assert.ifError(result.error); assert.equal(result.status, 0, result.stderr); statuses.push(result.status);
  }
  const history = join(root, '.artifacts/browser-runs');
  const records = readdirSync(history).map(name => ({ record: JSON.parse(readFileSync(join(history, name, '.browser-run.json'), 'utf8')),
    report: readFileSync(join(history, name, 'playwright/report'), 'utf8') }));
  const result = { statuses, completedUnpinnedRecords: records.length, invocation: records[0].record.invocation,
    recordStatuses: records.map(value => value.record.status), retainedProducerBytes: records.map(value => value.report).sort() };
  writeFileSync(process.argv[3], JSON.stringify(result, null, 2));
  console.log(JSON.stringify(result, null, 2));
  if (process.argv[4] === '--expect-three') {
    assert.equal(records.length, 3);
    assert.deepEqual(result.retainedProducerBytes, ['producer 3', 'producer 4', 'producer 5']);
  }
} finally { rmSync(root, { recursive: true, force: true }); }
