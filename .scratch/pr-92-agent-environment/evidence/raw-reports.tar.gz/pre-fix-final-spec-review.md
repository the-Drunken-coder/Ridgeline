# Spec review for #93 and #101

Date: 2026-10-05 UTC.
Reviewer: independent Spec-axis subagent `/root/spec_review`.
Spec: `.scratch/pr-92-agent-environment/spec.md`.
Base: `bf4cfca0ccaa7b781f7e3671d4982000bc9c3c50`.
Reviewed head and executed checkout: `83abbd8315e9121fce9c2940ad6623e614709f2a` in `/home/ubuntu/.t3/worktrees/Ridgeline/t3code-45512488`.
The tracked checkout was clean before and after execution. Only isolated temporary fixtures and this transient report were created. No browsers, shared consumer outputs, or tracked files were changed.

## Main report

One actionable implementation finding:

- **P2: failed output can be marked retained without a snapshot.** In `scripts/browser-resources.mjs:172-181`, a symlink anywhere inside an existing capture directory causes the entire snapshot to be skipped. `finish(true)` nevertheless writes a completed failure record and `.pin`, then releases the lock. An executed isolated filesystem history produced a pinned directory with no failure producer, allowed the next run, and lost the only producer during fixed-output replacement. This violates spec line 81: “keep required failure output available until it is retained or explicitly released.” Refuse finalization of existing protected or unsnapshotable capture output and retain the lock until the owner preserves it. Add the corresponding process regression.

No other implementation defect or unrequested scope was demonstrated. The requested measurement gate, focused review references, private observation helpers, bounded idle diagnostics, and promotion workflow are present. Existing parser and callback contracts remain intact.

Acceptance remains pending separately: the full combined local validation, required hosted results and actual checkout for this revision, final curated promotion, and shared thirteen-criterion closeout record were not yet available at review time. This is not a clean acceptance or merge-readiness report. Spec criteria 1-3 and 6-13 require the coordinator's combined execution evidence; this review's focused tests do not substitute for those runs. Hardware/browser acceptance and the triangle guideline remain in #80/#91. The historical extra culling frame remains unexplained.

## Executed checks

All commands ran on the clean pinned checkout above and exited 0:

```sh
node --test --test-name-pattern='measurement verification must succeed|gate only succeeds|local full validation' scripts/validation.test.mjs
node --test scripts/test-browser.test.mjs scripts/test-measurement.test.mjs scripts/promote-evidence.test.mjs
node --import tsx --test tests/browser-observation.test.ts tests/model-glb.test.ts tests/entity-scene.test.ts
git diff --check bf4cfca0ccaa7b781f7e3671d4982000bc9c3c50...83abbd8315e9121fce9c2940ad6623e614709f2a
```

The first command passed 4 cases, the second 26 cases including nested real-child interruption cases, and the third 34 cases: 64 total with no failures, cancellations, skips, or retries. The gate command uses the real executable aggregate checker. The local-orchestration fixture substitutes the costly commands while executing the actual configured orchestration. Resource/promotion/provenance cases use temporary Git repositories, real files, locks, symlinks, processes, and archives; costly browser/build commands are substituted. The parser and entity cases execute the existing module interfaces. No viewport pixel or native teardown result is claimed from these focused Node tests.

## Attempted histories and outcomes

| Guarantee | Attempted history | Outcome and evidence boundary |
| --- | --- | --- |
| Measurement completeness | Give the executable gate success, failure, cancellation, skip, and missing measurement results while all other prerequisites succeed. Execute the actual configured local command with command logging and an injected measurement failure. | Executed: only complete success passes; the local command preserves all seven ordinary stages and invokes measurement once; injected failure exits 19. |
| Measurement provenance | Run the Node wrapper in a temporary repository with distinct source SHA, PR head, and hosted checkout context; make its probe fail. Record context before dependencies exist. | Executed: raw stage output and failed status survive, and source/PR/workflow revisions remain distinct. Actual current hosted producer output remains pending. |
| Capacity refusal and recovery | Simulate 47/48-byte or unreadable capacity at `statfsSync` for all four real entrypoint processes; restore threshold capacity; exercise an explicit zero override and invalid negative override. | Executed: insufficient/unreadable capacity exits before expensive commands; restored capacity and explicit override permit normal orchestration. Invalid override rejects. |
| Existing process ownership | Overlap real runner processes while the owner pauses; interrupt a real command using timeout and signal with a surviving grandchild; leave an abandoned lock. | Executed: overlap cannot run commands or replace the consumer. Interrupted ownership and its partial output survive; a missing parent does not steal the lock. Explicit release permits retry. |
| Bounded retention | Complete repeated successful runs after a failed captured run; include running/interrupted records, tracked members, pinned output, unknown records, symlink-bearing records, curated source, and external targets. Release a selected failure deliberately. | Executed existing regressions: three eligible records remain; pinned/protected evidence and symlink targets survive; the released old producer becomes eligible. The additional capture history below demonstrates a gap that those regressions miss. |
| Failure capture | Create a real owned packaged run in an isolated checkout, request capture, then produce `failure.json` plus an external-directory symlink under the current fixed output. Finish as failed, claim the next run, and replace its fixed output. | Executed new reproduction: before replacement `.pin=true`, snapshot=false, lock=false. The next claim succeeds. After replacement both producer copies are absent while the external target survives. This supports the P2 finding. Raw result: `/tmp/ridgeline-93-context/spec-failure-capture-probe.json`. No Playwright process was run; fixed-output replacement was simulated with the same real recursive filesystem deletion boundary. |
| Byte-exact promotion | Dry-run and publish actual selected files and raw bytes; check extracted archive bytes/hashes, transient ignore ownership, retained links, rejected tracked/symlink/outside sources, repeat publication, and retention before/after explicit producer-pin release. | Executed: byte-exact archives and curated records survive; invalid plans fail without publication or pin release. The coordinator's final actual evidence set remains pending. |
| Coordinate conversion | Convert CSS coordinates using different horizontal/vertical scales and both top and WebGL bottom origins. | Executed focused helper cases: the expected target cell and pixel-center CSS coordinates agree. Actual map ratio 1/2 and browser-DPR workflows were inspected, not run by this reviewer. |
| Whole polling deadline | Observe a promise that never completes. Separately return visibly sufficient pixels only after 100 ms, beyond a 25 ms deadline, and wait another 140 ms after rejection. | Executed: never-completing observation rejects; the late visible result rejects at 25.995 ms and does not restart polling. The latter raw result is `/tmp/ridgeline-93-context/spec-deadline-probe.json`. A delayed screenshot and absent-model production-browser case exists; its current browser evidence belongs to the coordinator. |
| Parser bounds | Run moderate and safely rejected huge implicit POSITION/NORMAL/UV/color/index metadata alongside supported solid, quantized, interleaved, mirrored, indexed, and material/image assets. | Executed: all 21 existing parser cases pass. Inspected: stored accessors are bounded by stride/component/range before decoding; implicit scalars are bounded by GLB byte length before zero allocation; derived indices, positions, and upload arrays follow accepted counts. Repeated mesh/image decoding can multiply aggregate output and has no independent quota. No exhaustion workload or arbitrary restriction was introduced. |
| Entity callback ownership | Run style/sample remove/replace, failed-style retained placement, preparation failure, unchanged terrain ownership, and selection rebuilding through `EntityScene`. Trace the documented public browser histories through the actual state owners. | Executed: 10 entity cases pass. Inspected: `FeatureStore` accepted snapshots, `EntityScene` retained preparation/currentness checks, `Elevation` operation/abort ownership, `ModelLayer` completed publication, feature-publication submission/restoration tokens, and viewport DOM teardown before destroy listeners match the focused reference. Existing seven-case worker browser evidence is historical at its recorded revisions, not this review's browser execution. |
| Idle observation | Trace enabled/disabled schedules, observer registration, bounded events/retained observations, method restoration, full interval assertion, delayed terrain publication, stationary recovery, and destruction after the interval. | Inspection: private timing calls are gated by both opt-in flags; event recording does not schedule frames; the helper restores listeners/flags/its own repaint wrapper. The assertion requires 5000 ms, zero renders, and `quiet`, so stopped observations cannot claim quiet. The real controlled delayed-publication case retains pending entity work and its elevation scheduling cause, then checks settled enabled/disabled scenes. This reviewer did not run that browser case. |

## Callers and owners traced outside the diff

- Local commands in `package.json` and all four resource-handled entrypoints; `playwright.playground.config.mjs` and `control-lab/playwright.config.ts` start real production builds after the wrapper claims ownership. The packed consumer is prepared by `scripts/prepare-consumer.mjs`; copied helpers remain test support.
- `tools/model-measurement/instrumentation.test.mjs` invokes `scripts/measure-models.mjs --verify`; that runner builds/packs, installs, typechecks, and builds its separate consumer before the real probe. The existing workload tests retain the 40 CSS px assertion.
- `.github/workflows/validation.yml` adds measurement to the dedicated job and aggregate `needs`; the actual checker verifies every required job result. Node-only context recording precedes measurement prerequisites, and upload runs even after failure.
- `src/model-glb.ts`, `src/features.ts`, `src/entities.ts`, `src/elevation.ts`, `src/sensor-camera-coverage.ts`, `src/model-layer.ts`, `src/feature-publication.ts`, and `src/viewport.ts` provide the parser and callback ownership seams mapped by the guidance.
- `playground/model-example.ts` remains the consumer owner of asset requests and appearance controls. The screenshot predicate retains its alpha/color/body criterion, converts actual image dimensions into CSS input coordinates, and preserves actual hover/click/keyboard workflows and fixture budgets.
- `src/model-measurement.ts` clears timing entries immediately while the existing observer receives queued copies; default disabled tracing adds no timing entries. `tests/packaged/browser.spec.ts` writes revision/command-linked idle evidence as a file-backed attachment before cleanup. `scripts/promote-evidence.mjs` verifies captured bytes and archive members without making a fresh runtime-check claim.

## Remaining limits and interpretation

This review is an independent Spec-axis report for the pinned head. It contains one demonstrated implementation finding. Other suspected or constructed histories that passed are recorded above instead of being treated as proof of every possible permutation.

The full local browser/measurement pipeline, all current hosted results, actual hosted producer artifact inspection, final selected visual/evidence promotion, and thirteen-criterion coordinator record were still pending when this report was written. A listing of executable cases is coverage availability, not execution evidence. Focused Node checks do not establish browser pixels, native rendering/teardown, physical-GPU performance, target-browser support, or long-session bounds. The Apple M1 Pro/discrete-GPU/installed-browser matrix and measured triangle guideline remain intentionally pending in #80 and #91. The historical extra hosted culling frame's cause remains unknown.

Any fix after `83abbd8315e9121fce9c2940ad6623e614709f2a` requires a revision-pinned reassessment and appropriate checks. This report's successful executions and finding do not automatically advance to a later head.
