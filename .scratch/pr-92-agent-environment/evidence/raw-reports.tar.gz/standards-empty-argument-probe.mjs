import { execFileSync, spawnSync } from 'node:child_process';
import { mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const resource = pathToFileURL(resolve('scripts/browser-resources.mjs')).href;
const root = mkdtempSync(join(tmpdir(), 'ridgeline-standards-empty-argument-'));
try {
  execFileSync('git', ['init', '--quiet'], { cwd: root });
  writeFileSync(join(root, '.gitignore'), '.artifacts/\n');
  const code = `import { claimBrowserRun } from ${JSON.stringify(resource)};
    process.env.RIDGELINE_BROWSER_MIN_FREE_BYTES = '0';
    claimBrowserRun(process.argv[1], 'packaged').finish();`;
  for (let i = 0; i < 5; i++) {
    const run = spawnSync(process.execPath, ['--input-type=module', '-e', code, root, ''], { encoding: 'utf8' });
    if (run.status !== 0) throw new Error(run.stderr);
  }
  const pool = join(root, '.artifacts/browser-runs');
  const records = readdirSync(pool).map(name => JSON.parse(readFileSync(join(pool, name, '.browser-run.json'), 'utf8')));
  console.log(JSON.stringify({ realCompletedRecords: records.length,
    statuses: records.map(record => record.status), lastArguments: records.map(record => record.invocation.at(-1)) }));
} finally { rmSync(root, { recursive: true, force: true }); }
