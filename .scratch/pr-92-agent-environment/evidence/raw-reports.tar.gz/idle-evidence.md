# Idle scheduling evidence for #99

Recorded 2026-10-05 16:52 UTC. Integration owner is root, with combined verification tracked in #101.

## Reviewed and exercised source

Canonical ticket: `/tmp/ridgeline-93-context/99.md`. Spec: `.scratch/pr-92-agent-environment/spec.md`.

Reviewed baseline: `2df316afb75c39a6e9887a4c5e06a93af61563f0`. Reviewed owned implementation commit: `183be69abc5554fc9c433c179122f58f0fc940b9`. Merged current integration tip `ab8cdf2d636b19be0bdad3305e3d3c1d80c33ae1`, producing clean owned branch head `de7f551fe9cba60287dcbf60e8462da78dd686d9`.

The packed checks exercised the dirty checkout at baseline `2df316a`, immediately before committing the identical owned file bytes in `183be69`. The trace embeds actual HEAD, status, tracked diff SHA256, command, and test case. Its tracked diff digest is `079d5ede95d4c2036f0fb0253adb4545878a6503b0d9df22e4e2e08f30c1667b`. Because the new helper was then untracked, its exact byte digest is separately pinned below. This scoped evidence does not claim the later combined integration head was exercised.

Temporary shared hooks were permitted by root for scoped execution only: helper copy in `scripts/prepare-consumer.mjs`, idle case in `tests/browser-cases.ts`, and actual-source injection plus file-backed attachment in `tests/packaged/browser.spec.ts`. Saved patch: `/tmp/ridgeline-93-context/idle-test-wiring.patch`, SHA256 `0be3c674077262d86abd2873ff8fe9c364c8d422ee486ec172d8b956ce765f71`. Those hooks were restored and excluded from the commit. Root integrates helper copy/manifest, while #98 owns the final attachment bridge. The temporary bridge records actual Playwright worker argv; the explicit runner command is pinned below. Final bridge uses the runner-provided invocation when available.

Exact owned source bytes exercised and committed:

- `src/entities.ts`: `4512b62449c4902dcc5c9985e04f1f53412d4cb4018738a2c71ea216d7bf2de9`
- `src/model-measurement.ts`: `04b654f20ca7ed280be1886770af129836b45c4c8178166000f693991c3530c4`
- `tests/model-frame-review.browser.ts`: `e326371a44ff76d6d1e756328e71adb4b8704ecd07dfb3657fa19d4371e6042d`
- `tests/browser-idle.ts`: `9f74b8a3dab5f5992a25e3f1d376ed7334fd2ba7149dcd30f63caf9a8dad84cc`

## Executed workflow and results

All commands ran in `/tmp/ridgeline-93-idle` with a separately packed consumer, Chromium/WebGL, and the real public elevation sampler.

1. `node scripts/test-browser.mjs --grep 'Model idle observation records delayed publication'` initially failed because existing timing records could not identify terrain scheduling. Added private opt-in scheduling, preparation, scene revision, update revision, and pending-work facts.
2. The same real delayed-publication workflow failed again after adding destruction-after-budget coverage: `A stopped observation claimed quiet after its elapsed budget`. The raw failed producer was retained and copied byte-for-byte as `idle-disposal-red.json`. The helper now requires successful `quiet` completion, stops cannot supply a success outcome, and disposal retires listeners, wrappers, flags, and pending wait timers.
3. `node scripts/test-browser.mjs --grep 'Model idle observation records delayed publication|Models cull off-screen'` passed both cases in 33.5 seconds. The culling history preserves its original geometry, current-pose recovery, picking, and full five-second zero-render requirement. The new case catches an expected internal idle failure caused by releasing held terrain work with stationary input, then proves current blue appearance and relocated pixels after recovery.
4. `pnpm check` passed.
5. `node --import tsx --test tests/entity-scene.test.ts` passed all 10 behavioral tests.
6. `git diff --check` passed before committing.

Green delayed-publication reports:

| Observation | Outcome | Duration ms | Renders | Event count | Dropped events |
| --- | --- | ---: | ---: | ---: | ---: |
| Held terrain released during observation | failed as expected | 5000.9 | 4 | 34 | 0 |
| Settled recovery, instrumentation enabled | quiet | 5000.6 | 0 | 128 | 73 |
| Settled recovery, instrumentation disabled | quiet | 5000.3 | 0 | 1 | 0 |
| Destroyed after elapsed budget | stopped and assertion rejected | 5001.9 | 0 | 1 | 0 |

The expected failure contains an `elevation-change` scheduling cause at about 353.4 ms, `sceneRevision: 5`, `updateRevision: 1`, `pendingEntities: 1`, `framePending: false`, followed by entity preparation, native render, completed model frame, and `entitychange` publication events. Source revision is actual checkout HEAD, not an Actions SHA. Observation never captures pixels or schedules repaint; the wrapper only records calls made by existing render paths. Enabled and disabled comparisons preserve the GPU work count, and stopping restores the original trigger method and prior opt-in flags. Browser records retain at most four reports of 128 events each, with bounded event details.

Raw producer copies and SHA256:

- `/tmp/ridgeline-93-context/idle-green.json`: `7f6d60c0ce38251e7195114adc07806ee1a3d20da07555ce65a2e1b685755fb2`
- `/tmp/ridgeline-93-context/idle-culling-green.json`: `4111fa1b701ff3ccd274e2186f6aca490b4e715dd7bdcfaa941a9d9aa353e970`
- `/tmp/ridgeline-93-context/idle-disposal-red.json`: `e49c2456f37113ee4e2ec116913017cbdea3a793a1cdcc89509455e16f7f24f1`

Original green outputs remain under `.artifacts/playwright/browser-Model-idle-observa-42e3f-t-after-stationary-recovery/idle-observations.json` and `.artifacts/playwright/browser-Models-cull-off-sc-f6080-nd-recover-on-camera-motion/idle-observations.json`, with Playwright path attachments and browser-run snapshots. Original failed run evidence is retained in its pinned browser-run snapshot. Passing expected-negative evidence must be written as a real JSON file before attaching by path; body-only attachments with the list reporter did not leave a raw JSON producer.

## Integration and limits

Root must copy `tests/browser-idle.ts` into the packed fixture and register the exact case name `Model idle observation records delayed publication and stays quiet after stationary recovery` immediately after the existing culling case. #98 commit `a8f92023cbb25df04bc5b2d585047eace2317af4` supplies the final actual-source context and file-backed always-attach bridge. Port 5174 was released to #98 after scoped checks.

These are current software checks on this local Chromium environment. No hosted check or hardware acceptance is claimed. The historical unexplained extra culling frame remains an explicit gap; this controlled terrain failure establishes the cause of the executed negative only. Combined clean-source packed verification remains root's #101 responsibility.
