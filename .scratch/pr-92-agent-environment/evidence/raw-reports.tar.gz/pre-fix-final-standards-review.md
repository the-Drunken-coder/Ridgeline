# Standards review for issues #93 and #101

Recorded 2026-10-05 UTC. Reviewed base `bf4cfca0ccaa7b781f7e3671d4982000bc9c3c50` through head `83abbd8315e9121fce9c2940ad6623e614709f2a` using `git diff bf4cfca0ccaa7b781f7e3671d4982000bc9c3c50...83abbd8315e9121fce9c2940ad6623e614709f2a`. Execution checkout was `/home/ubuntu/.t3/worktrees/Ridgeline/t3code-45512488`. Tracked status was clean before and after the review. This review reports the pinned original revision; later fixes require a separate review.

## Main report

Two documented-standard violations remain at this revision.

1. `scripts/browser-resources.mjs:55` treats malformed ownership records as disposable. `CODE_CONVENTIONS.md` requires validation of unknown external values before narrowing and a clear resource owner/disposal path. An executed isolated checkout contained an old record with the expected owner/version/command and completion status, but invalid `pid`, `startedAt`, and `invocation`. The next run deleted its producer evidence. Validate the recognized record shape before adding it to the deletion set. The existing malformed-record regression only supplies JSON `null`.
2. `scripts/browser-resources.mjs:172` silently skips rejected output capture, then records completion and releases ownership. The same clear-owner/disposal rule, together with `CODE_CONVENTIONS.md`'s prohibition on silent failure fallback, requires unsuccessful retention to preserve the owner and evidence. A failed output containing an ordinary failure log plus a symlink produced a pinned history record with no failure log, released the lock, and allowed another run to replace the sole original. Treat rejected snapshot ownership as a retention failure, preserving the fixed output and lock. This also applies when capture finds a newly tracked or nonignored output.

No additional Fowler baseline smells warrant a finding. The private instrumentation, test observation helpers, and promotion command serve concrete requirements and retain small interfaces. Tooling-enforced checks are outside this report.

The focused existing checks passed 32 process/report tests, three observation helper tests, and 52 parser/entity/model tests. Additional polling and capture-cleanup probes passed. Full browser validation, hosted verification, and evidence closeout were pending and are not claimed by this review.

## Sources and scope

Read `AGENTS.md`, the supplied working instructions, `CODE_CONVENTIONS.md`, `GLOSSARY.md`, `docs/agents/domain.md`, all three repository ADRs, `README.md` contracts, `docs/agents/issue-tracker.md`, and the canonical `.scratch/pr-92-agent-environment/spec.md`. Reviewed the full 34-file diff and the commit list, with detailed inspection of changed runtime paths and their callers outside the diff. Repository rules override the Fowler heuristic baseline. No tracked file was edited.

## Executed histories

### Unknown completed ownership record

`standards-malformed-retention-probe.mjs` creates a real temporary Git checkout with ignored output, produces three complete records through `claimBrowserRun`, and adds a completed record with an old timestamp. The candidate's `pid` is a string, `startedAt` is a boolean, and `invocation` is null. The next claimed run deletes that candidate and its evidence, then retains three normal records. `standards-malformed-retention.stdout.log` records `malformedRecordPreserved:false`. The probe cleans its temporary checkout and does not mutate shared browser output.

This is execution through the ownership helper's existing interface. It shows that structurally invalid and valid completed records reach the same eligibility classification. It does not fill the disk or infer child-process termination from a missing PID.

### Snapshot refusal classified as successful retention

`standards-snapshot-symlink-probe.mjs` uses another temporary ignored-output checkout. A claimed packaged owner receives an ordinary `failure.log` and a symlink alongside it. `capture()` followed by `finish(true)` creates the history pin, skips the complete snapshot, writes failed/completed metadata, and removes the lock. A second owner is allowed to start. Raw output in `standards-snapshot-symlink.stdout.log` records:

```json
{"failurePinned":true,"failureSnapshotPresent":false,"lockRetained":false,"subsequentRunAllowed":true,"externalPreserved":true}
```

Inspection of `scripts/test-browser.mjs`, the app wrapper, and their configured Playwright output paths establishes that subsequent execution writes the same fixed output location. The isolated probe establishes the ownership and missing-snapshot failure without substituting browser pixels for execution evidence. The symlink target survives. The failure concerns the missing retained regular file and released ownership, not deleting the external target.

### Existing process and report regressions

Executed:

```sh
node --test scripts/test-browser.test.mjs scripts/promote-evidence.test.mjs scripts/test-measurement.test.mjs scripts/validation.test.mjs
```

All 32 tests passed, with zero failures, cancellations, or skips. Raw output is `final-standards-node.stdout.log` and `final-standards-node.stderr.log`. The checks exercise low and unreadable capacity before setup, explicit overrides, overlap refusal, retained abandoned locks, actual surviving descendants after timeout/signal, three-record retention, pinned failure release, tracked/permanent/symlink protections, promotion dry-run/publication, rejected sources/destinations, archived byte equality, and real installed Playwright report production through the report consumer. The Playwright report fixtures perform Node-only cases in uniquely allocated fixture directories; no browser was launched.

### Polling deadline and listener retirement

Executed:

```sh
node --import tsx --test tests/browser-observation.test.ts
node --import tsx /tmp/ridgeline-93-context/standards-observation-lifecycle-probe.mjs
```

The three existing tests passed. The additional isolated probe lets one observation resolve after its 25 ms deadline, then waits long enough to check later activity. The observation runs once; the visible criterion never runs after expiration; no second poll starts. Capture probes exercise no render, missing WebGL, a thrown repaint, and successful readback. Every outcome removes its registered render listener. The capture owner uses a minimal event/readback fixture only to establish timer/listener retirement. It does not establish real WebGL pixels, pointer behavior, or device-pixel-ratio support. Raw output is in `final-standards-observation.*.log` and `standards-observation-lifecycle.*.log`.

### Parser and entity/model state

Executed:

```sh
node --import tsx --test tests/model-glb.test.ts tests/entity-scene.test.ts tests/model-presentation.test.ts tests/model-switching.test.ts tests/models.test.ts
```

All 52 tests passed, with zero failures, cancellations, or skips. Raw output is `final-standards-models.stdout.log` and `final-standards-models.stderr.log`. The existing parser tests reject moderate and billion-count implicit declarations through the parser's allocation guard while accepting supported fixtures; no genuine billion-element allocation occurs. Entity and registry tests cover retained preparation, callback replacement/removal, context loss, aborted replacement, newest registration ownership, and disposal of uninstalled GPU results. These module results do not establish browser presentation or native remount behavior.

## Inspection traces and limits

- Traced preflight through all four runners, exact subprocess invocation propagation, consumer replacement, snapshot creation, lock finalization, and history pruning. The shared directory lock owns expensive operations; timeout/signal paths retain interrupted metadata without PID-based takeover. Ordinary successful captures use ignored regular output and bounded history. The two failures above are separate gaps in that ownership policy.
- Traced promotion from source/path validation through ignored staging, file copies, archive extraction and producer-byte comparisons, relative-link checking, rename publication, and cleanup. Existing process tests establish no partial publication for malformed plans, rejected paths, and broken links. The producer's pin remains until its owner explicitly releases it. Promotion checks bytes and structure, not the truth of recorded revision/check claims.
- Traced `waitForVisible` deadlines and all call sites. Fixture-specific model color/alpha/body criteria remain in their owners, and successful coordinates drive real input in the browser cases. The packed helper uses actual independent canvas/CSS scales and WebGL origin. Playground screenshot observation uses actual image dimensions and CSS bounds. Browser execution remains root-owned.
- Traced `observeIdle` through `Viewport.destroy`, `EntityScene` scheduling/preparation, `ModelLayer` publication, and `ModelMeasurement`'s opt-in boundary. The helper records bounded events, owns listeners/observer/wrapper restoration, does not call repaint itself, and rejects stopped observations even after five seconds. The controlled delayed-terrain case requires scheduling, frame, publication, and visible stationary recovery before enabled/disabled complete quiet intervals. These browser histories were inspected, not executed in this review.
- Traced the unchanged parser external count multiplication, implicit backing-length guard, stored accessor range checks, derived lists/typed arrays, node traversal and reused-mesh decoding. The new guidance explicitly distinguishes per-allocation bounds from aggregate expansion. No new arbitrary asset quota was introduced. Native image decoding, hardware memory budgets, and aggregate exhaustion remain outside this review.
- Read the entity ownership reference against its owners in `features.ts`, `viewport.ts`, `entities.ts`, `elevation.ts`, `sensor-camera-coverage.ts`, `model-layer.ts`, and native publication modules. It distinguishes accepted snapshots, successful preparation, and completed drawing/picking, and its case names map to existing executable histories. A linked case is available coverage, not proof it passed at this revision.

No hosted results or full browser run are included here. Later root checks and promoted closeout evidence must identify their own exercised revision. The root's follow-up review must assess both demonstrated retention fixes on the final integrated head.

The three additional probe sources are intended for the raw archive. They import the checked-out repository relative to the current working directory. After extracting them, replay from the pinned repository checkout with `node <extracted-directory>/standards-malformed-retention-probe.mjs`, `node <extracted-directory>/standards-snapshot-symlink-probe.mjs`, and `node --import tsx <extracted-directory>/standards-observation-lifecycle-probe.mjs`.
