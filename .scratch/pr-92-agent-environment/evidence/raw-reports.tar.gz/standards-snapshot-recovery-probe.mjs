import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const { claimBrowserRun } = await import(pathToFileURL(resolve('scripts/browser-resources.mjs')).href);
process.env.RIDGELINE_BROWSER_MIN_FREE_BYTES = '0';
const results = [];
for (const protection of ['symlink', 'tracked', 'nonignored']) {
  const root = mkdtempSync(join(tmpdir(), 'ridgeline-standards-recovery-'));
  try {
    execFileSync('git', ['init', '--quiet'], { cwd: root });
    writeFileSync(join(root, '.gitignore'), '.artifacts/\n');
    const owner = claimBrowserRun(root, 'packaged');
    const output = join(root, '.artifacts/playwright');
    mkdirSync(output);
    writeFileSync(join(output, 'failure.log'), 'failure producer bytes\n');
    writeFileSync(join(root, 'external.log'), 'external must survive\n');
    if (protection === 'symlink') symlinkSync(join(root, 'external.log'), join(output, 'external.log'));
    if (protection === 'tracked') execFileSync('git', ['add', '-f', '.artifacts/playwright/failure.log'], { cwd: root });
    if (protection === 'nonignored') writeFileSync(join(root, '.gitignore'), '.artifacts/browser-runs/\n.artifacts/browser-run.lock/\n');
    owner.capture();
    assert.throws(() => owner.finish(true), /Refusing to retain protected browser output/);
    assert.equal(existsSync(join(root, '.artifacts/browser-run.lock')), true);
    assert.equal(existsSync(join(owner.directory, '.pin')), true);
    assert.equal(readFileSync(join(output, 'failure.log'), 'utf8'), 'failure producer bytes\n');
    assert.throws(() => claimBrowserRun(root, 'packaged'));
    if (protection === 'symlink') rmSync(join(output, 'external.log'));
    if (protection === 'tracked') execFileSync('git', ['rm', '--cached', '.artifacts/playwright/failure.log'], { cwd: root });
    if (protection === 'nonignored') writeFileSync(join(root, '.gitignore'), '.artifacts/\n');
    owner.finish(true);
    assert.equal(existsSync(join(root, '.artifacts/browser-run.lock')), false);
    assert.equal(readFileSync(join(owner.directory, 'playwright/failure.log'), 'utf8'), 'failure producer bytes\n');
    for (let i = 0; i < 5; i++) claimBrowserRun(root, 'packaged').finish();
    assert.equal(readFileSync(join(owner.directory, 'playwright/failure.log'), 'utf8'), 'failure producer bytes\n');
    assert.equal(readFileSync(join(root, 'external.log'), 'utf8'), 'external must survive\n');
    results.push({ protection, lockRetainedAfterRefusal: true, subsequentRunBlocked: true,
      ownerRetryCompletedSnapshot: true, pinnedBytesSurvivedRepeatedRuns: true });
  } finally { rmSync(root, { recursive: true, force: true }); }
}
console.log(JSON.stringify(results));
