import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const { claimBrowserRun } = await import(pathToFileURL(resolve('scripts/browser-resources.mjs')).href);

const root = mkdtempSync(join(tmpdir(), 'ridgeline-standards-retention-'));
process.env.RIDGELINE_BROWSER_MIN_FREE_BYTES = '0';
try {
  execFileSync('git', ['init', '--quiet'], { cwd: root });
  writeFileSync(join(root, '.gitignore'), '.artifacts/\n');
  for (let i = 0; i < 3; i++) claimBrowserRun(root, 'packaged').finish();
  const history = join(root, '.artifacts/browser-runs');
  const sample = JSON.parse(readFileSync(join(history, readdirSync(history)[0], '.browser-run.json'), 'utf8'));
  const malformed = join(history, 'packaged-malformed-completed');
  mkdirSync(malformed);
  writeFileSync(join(malformed, '.browser-run.json'), JSON.stringify({
    owner: sample.owner, version: sample.version, command: sample.command,
    status: 'complete', completedAt: '2000-01-01T00:00:00.000Z',
    pid: 'not a process', startedAt: false, invocation: null,
  }));
  writeFileSync(join(malformed, 'selected-producer.log'), 'unknown ownership evidence\n');
  const next = claimBrowserRun(root, 'packaged');
  next.finish();
  console.log(JSON.stringify({ malformedRecordPreserved: existsSync(malformed), remainingRuns: readdirSync(history).length }));
} finally { rmSync(root, { recursive: true, force: true }); }
