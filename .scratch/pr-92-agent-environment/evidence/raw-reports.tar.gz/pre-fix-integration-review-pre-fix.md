# Integration review before resource follow-up

Owner: root Codex coordinator for #101. Date: 2026-10-05 UTC.

Base: bf4cfca0ccaa7b781f7e3671d4982000bc9c3c50. Reviewed clean head: 83abbd8315e9121fce9c2940ad6623e614709f2a.

Root inspected the complete combined diff, including wrapper callers, required-job aggregation, measurement producer context, generated-output ownership, promotion publication, pixel readiness consumers, private scheduling hooks, and observer disposal. The public viewport exports and model parser remain unchanged. The registry manifest and packed helper copies match actual browser case order.

Concrete histories: all four resource entrypoints reach capacity checks before expensive commands; unfinished child processes retain shared ownership; parser implicit count rejection precedes allocation and supported decoding remains preserved; current model publication is distinct from visible screenshot readiness; browser ratio2/map ratios1 and2 retain real pointer input; private scheduling observation does not call repaint or read pixels; stopped idle observations cannot claim quiet after the elapsed budget; promotion stages bytes and verifies links before publishing, while retention requires explicit pin release. Executable checks are recorded separately from inspection.

Independent review demonstrated two incomplete retention guarantees: malformed ownership records could be pruned, and symlink-bearing failure output could be skipped while releasing its lock. These remain open at this revision. Root accepted both reproductions and assigned one isolated implementer to fix them. Current full local and hosted checks exercise this pre-fix revision; their success cannot establish the corrected guarantees. Final review, current checks and closeout follow the fix.
