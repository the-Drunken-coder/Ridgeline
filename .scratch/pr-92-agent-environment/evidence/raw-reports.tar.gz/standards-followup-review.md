# Final Standards followup for issues #93 and #101

Latest Standards conclusion: clean at `361af95d341c441e6d7598626d7bc5c51a62fcb7`. The addendum below records its distinct review and execution scope. The earlier `ee49a4b` resource-fix investigation remains historical evidence for unchanged source blobs.

Recorded 2026-10-05 UTC. Original base `bf4cfca0ccaa7b781f7e3671d4982000bc9c3c50`; final reviewed and exercised head `ee49a4b4b6df0526b06a2576b50e39307a8c57ae`. Execution checkout `/tmp/ridgeline-93-review-fixes`, branch `implement/93-review-fixes`, was clean in tracked files before and after execution. Reviewed the full base-to-head scope together with the original Standards report, then investigated the focused `83abbd8315e9121fce9c2940ad6623e614709f2a..ee49a4b4b6df0526b06a2576b50e39307a8c57ae` diff. Only the resource helper and its two process-test files changed after the original review.

## Main report

Both original documented-standard violations are resolved. No remaining hard violations or Fowler smell findings were found in this reassessment.

Completed-record pruning now requires recognized owner/version/command/status, a positive safe-integer PID, string invocation arguments with a nonempty executable, canonical start/completion timestamps, and completion no earlier than start. Unknown or malformed ownership remains protected. Sorting uses numeric completion time. Replaying the original malformed-record probe preserves its evidence.

Present output rejected for symlink, tracked, or nonignored ownership now raises an explicit retention error. Finalization preserves the lock, original producer bytes, and failure pin. Independent histories confirmed subsequent work is blocked; after protection is resolved, the existing owner can finish the snapshot and release the lock. Pinned failure bytes survive repeated later runs.

The intermediate fix `215a5b0` incorrectly rejected empty later arguments and left complete records outside bounded retention. A real subprocess probe demonstrated five retained records. Final head `ee49a4b` allows legitimate empty string arguments while rejecting an empty executable. The same probe now retains three records; the new wrapper regression verifies actual forwarding of `--grep ''` and the three newest report snapshots.

At final head, 30 focused process tests passed with zero failures, cancellations, or skips. The original review applies to unchanged hunks. Root-owned full local/browser and hosted checks require their own exercised revision record; this report makes no claim for those checks or merge readiness.

## Attempted histories and evidence

### Original malformed-record deletion

Executed `node /tmp/ridgeline-93-context/standards-malformed-retention-probe.mjs` from the final checkout. The probe uses the real ownership helper in a separate temporary Git checkout with ignored output. Three complete producer records coexist with an old malformed record containing invalid PID/start/invocation metadata. The next run preserves that malformed record and prunes a valid old producer. `standards-final-followup-malformed.stdout.log` reports `malformedRecordPreserved:true` and four remaining records, three disposable and one protected. Standard error is retained separately.

The same outcome was executed at intermediate `215a5b0`, recorded in `standards-followup-malformed.*.log`. The original `83abbd8` result remains a historical failure in the original report.

### Rejected snapshot and recovery

At intermediate `215a5b0`, the original `standards-snapshot-symlink-probe.mjs` exits nonzero at `finish(true)` with an explicit refusal and retained-lock recovery message. Its output is in `standards-followup-snapshot.*.log`. This is the intended changed outcome of the original failure history.

At final head, executed `node /tmp/ridgeline-93-context/standards-snapshot-recovery-probe.mjs`. Three independent real temporary checkouts exercise a symlink inside producer output, a producer file tracked after owner acquisition, and output made nonignored after owner acquisition. Each history confirms:

- Snapshot rejection throws an explicit error and preserves the lock, pin, original failure log, and external target.
- A subsequent owner cannot start while evidence ownership remains unresolved.
- Resolving protection allows the original owner to retry `finish(true)`, retain its complete snapshot, and release the lock.
- Five later successful runs leave the pinned failure bytes and external target intact.

`standards-final-followup-snapshot.stdout.log` records all three successful histories. The expected refusal/recovery diagnostics are retained in `standards-final-followup-snapshot.stderr.log`. These are executions through the helper's real filesystem and ownership interface, with no browser or fake process termination. They do not substitute for real browser presentation checks.

### Valid empty arguments and bounded retention

Executed `node /tmp/ridgeline-93-context/standards-empty-argument-probe.mjs` at both `215a5b0` and final `ee49a4b`. Five real helper subprocesses receive an empty trailing argument and create their own complete unpinned metadata. At `215a5b0`, all five records remain because the predicate mistakes a valid argument for malformed ownership. At final head, exactly three remain with their empty arguments preserved. Raw output is `standards-followup-empty-argument.*.log` and `standards-final-followup-empty-argument.*.log` respectively.

The final process suite additionally executes the actual wrapper six times with `-- --grep ''`. Its substituted costly command records the received argument vector and produces regular report bytes. It verifies the three latest snapshots, retirement of the oldest record, absence of pins, and preservation of the empty argument in both owner metadata and the forwarded subprocess command. This tests observable retention and forwarding at the wrapper boundary, rather than asserting source text.

### Focused process suite

Executed at final head:

```sh
node --test scripts/test-browser.test.mjs scripts/promote-evidence.test.mjs
```

All 30 tests passed. Raw output is `standards-final-followup-node.stdout.log` and `standards-final-followup-node.stderr.log`. The suite covers malformed completion metadata, canonical expanded-year numeric ordering, normal bounded history, protected failures, explicit release/recovery, real surviving descendants after timeout/signal, overlap refusal, preflight, symlinks, tracked/permanent files, archive byte equality and rejected publication. The promotion-retention fixture now obtains its running/interrupted records from the real producer. Its explicit fixture lock removal is documented as safe because it starts no children; actual surviving-child ownership is established by the separate process regressions.

At intermediate `215a5b0`, the same two-file suite passed 29 tests. That evidence is historical in `standards-followup-node.*.log` and does not cover the later empty-argument fix.

## Ownership and caller inspection

Re-traced `completedRunTime` through candidate selection, three-record pruning, owner creation and completion. Required metadata matches the real producer's field types and canonical timestamps. Invalid records do not become eligible based on PID liveness, and valid argument vectors can contain empty values after their executable. Numeric ordering avoids treating expanded ISO years as earlier solely because of lexical order.

Re-traced capture through the packaged, playground, control, and measurement callers. Missing output may be legitimate when setup fails before a producer exists. Present but rejected output fails finalization explicitly. The `finalized` guard releases the shared lock only after capture, complete metadata, and pruning succeed. A refusal retains running ownership and pinned failure data, protecting both the fixed producer path and its incomplete snapshot. The wrapper's nonzero outcome and recovery diagnostics expose that state.

The resource helper's public tooling interface is unchanged. The metadata validation remains a local predicate instead of a new framework or ownership service. The tests execute processes and actual filesystem protections; no source-text assertions, broad application cleanup, new public viewport API, or speculative abstraction was added. The original full review's parser, entity, observation and idle traces remain applicable because those blobs did not change.

## Source pins and remaining limits

Final reviewed blobs:

| File | Git blob |
| --- | --- |
| `scripts/browser-resources.mjs` | `080dff0d3c3de4a3540901649162aafbf1998bd2` |
| `scripts/test-browser.test.mjs` | `7377d0bb370dc9d5f99a6b68119514eeec568ebe` |
| `scripts/promote-evidence.test.mjs` | `ef5077814e5b07704088a4df23694359a3752994` |

The root integration checkout was still running checks against original `83abbd8` during this review. No result from that revision is described here as verification of these fixes. If integration creates a merge-only commit, the integration owner can compare these blobs and the remaining tracked tree with `ee49a4b`; runtime verification and hosted claims still require the recorded exercised revision. No shared browser output, port, or root tracked file was changed by this review.

The additional probe sources import the checked-out repository relative to the current working directory. After extracting the raw evidence archive, replay them from the pinned checkout using `node <extracted-directory>/standards-malformed-retention-probe.mjs`, `node <extracted-directory>/standards-empty-argument-probe.mjs`, and `node <extracted-directory>/standards-snapshot-recovery-probe.mjs`. Full validation, hosted execution, archive promotion and tracker closeout remain the integration owner's work.

## Standards addendum for playground fixture and hosted capture

Recorded 2026-10-05 UTC. Full reviewed scope is `bf4cfca0ccaa7b781f7e3671d4982000bc9c3c50...361af95d341c441e6d7598626d7bc5c51a62fcb7`. This phase reassessed `ee49a4b4b6df0526b06a2576b50e39307a8c57ae..361af95d341c441e6d7598626d7bc5c51a62fcb7` against the original and resource-fix Standards reports. Its only three changed files are the playground model test, validation workflow, and CI guide. Review and focused execution used the clean `/tmp/ridgeline-93-review-fixes` checkout at exact `361af95`.

### Main report for this phase

No remaining documented-standard violations or Fowler smell findings were found at `361af95`. The previous resource fixes are unchanged and retain the reviewed blob hashes above.

The absence fixture now reaches an empty scene through the existing real scenario selector. I traced model-consumer disposal, cancellation, listener retirement, shared viewport clearing, and the feature-count update. The map canvas remains in place. Delayed visible readiness, real model picking, the filled-body threshold, actual screenshot observations, and bounded absence rejection remain intact. No fixture, render, action, setup, or observation deadline was increased.

The playground's 35-minute hosted job now surrounds the existing 30-minute child runner. Its screenshot/trace upload is permitted after cancellation when output exists. The change preserves required-gate rejection and does not classify cancelled work as success. Artifact capture remains dependent on files and an available runner; no claim is made that an earlier missing blob was recovered.

Two focused executable gate tests passed at `361af95`, including rejection of failed, cancelled, missing, and skipped prerequisites. The workflow parses as YAML, seven existing relative documentation links resolve, and the focused diff check passes. I inspected the implementer's real production-case output showing a 1.9-minute pass, but did not rerun a browser in this review. Root's new full validation and hosted run require their own revision-specific evidence.

### Concrete histories and owner trace

For the history of a model becoming selected before all models disappear, traced `playground/main.ts`'s scenario change through `loadScenario`. It retires `mountModelExample`, hides its panel, clears the existing viewport's feature store and selection, adds no features for `empty`, and changes the camera through the existing reset action. It does not replace or hide the map canvas. `mountModelExample.destroy` invalidates pending work, aborts consumer fetches, removes selection/entity listeners, unregisters each shared example model, and restores the prior visibility configuration. Its disposed/revision checks prevent an older fetch from registering a model after the transition.

The feature-count assertion confirms accepted input is empty, while `waitForVisible` separately observes screenshots until the old filled body is absent. The negative check then observes the same criterion for three seconds and requires at least one completed pixel observation. The same `neighbors > 30` model criterion, alpha/color thresholds, actual image-to-CSS conversion, delayed opacity restoration, multi-observation readiness, and real canvas click remain. The deterministic gray/green background does not satisfy the teal threshold. Camera reset cannot substitute for feature removal because the zero-feature assertion and actual screenshot settlement both remain. Existing sample-removal coverage stays in the main model workflow.

For the history of a slow/failing suite whose parent cancels before report finalization, traced `.github/workflows/validation.yml` through `scripts/test-browser-app.mjs`, `claimBrowserRun.run`, and `playwright.playground.config.mjs`. The unchanged child subprocess timeout is 1,800,000 ms. Playwright still has one worker, zero retries, unchanged fixture/setup/render budgets, the same output directory, and failure-retained traces/screenshots. A 35-minute job permits the existing child bound plus ordinary setup/upload margin; it is not an extension of the model assertions' deadlines.

The upload condition explicitly includes a status function and checks for existing output. GitHub documents that `always()` remains true after cancellation and `hashFiles` returns an empty string when no files match. This supports the configured upload predicate, rather than proving an upload ran on a particular cancelled execution. [GitHub expression reference](https://docs.github.com/en/actions/reference/workflows-and-actions/expressions). A lost runner or exhausted parent timeout can still prevent capture; final hosted acceptance must inspect actual retained output.

The aggregate gate and its required job list are unchanged. Executed:

```sh
node --test --test-name-pattern='measurement verification must succeed|gate only succeeds' scripts/validation.test.mjs
```

Both selected tests passed with zero failures, cancellations, or skips. Raw output is `standards-361-gate.stdout.log` and `standards-361-gate.stderr.log`. These tests execute the gate subprocess against success and every required non-success prerequisite state. No browser or shared producer output was used.

Python 3 parsed the committed workflow, reported the 35-minute budget and guarded upload expression, and checked seven existing relative links and heading fragments in `docs/ci-validation.md`. Raw output is `standards-361-doc-workflow.stdout.log` and `standards-361-doc-workflow.stderr.log`. `git diff --check ee49a4b..361af95` passed. Parsing verifies syntax and structure, not GitHub expression execution. No tracked file was edited.

### Historical producer evidence and current limits

Inspected root's `hosted-first-playground.log` and `hosted-first-gate.log` from the `83abbd8` hosted execution. The producer log records the main pixel/input workflow passing in 7.4 minutes, the delayed/absent case failing in 10.1 minutes, and later job cancellation. The gate explicitly reports `playground-browser=cancelled` and exits nonzero. The failed case's detailed action/error and finalized blob are unavailable. These logs establish failure, cancellation, and gate rejection. They do not establish which action failed or the cause of the delayed case's failure.

Read the separate `playground-review-fix-evidence.md` record and `playground-review-fix-targeted.stdout.log` from the implementer. They report a production target-case pass in 1.9 minutes against `ee49a4b` with the three scoped files modified immediately before committing identical bytes as `361af95`. I compared the record's file hashes with its committed source pins; this is inspected producer evidence, not an independently repeated browser run. Root-reported full validation at `83abbd8` remains historical and does not verify the later resource or fixture/workflow changes.

New reviewed blobs at `361af95`:

| File | Git blob |
| --- | --- |
| `tests/playground/model-example.spec.ts` | `46f3a7e14322d77090febe61b00d3c29d9a558d3` |
| `.github/workflows/validation.yml` | `5e2172d6cb3142f686d4cb4a6e30efe45da81030` |
| `docs/ci-validation.md` | `208b8e3411ff796ddb21aad07fd30c2be8b78d09` |

The three resource helper/test blobs at `361af95` match `ee49a4b` exactly. Their 30-test process run and independent ownership probes therefore remain relevant unchanged-code evidence, dated and pinned above. They are not described as a new full run at `361af95`. Combined local verification, current hosted acceptance, final archive promotion, and tracker closeout remain root responsibilities. Standards completion is separate from those pending checks and merge readiness.
