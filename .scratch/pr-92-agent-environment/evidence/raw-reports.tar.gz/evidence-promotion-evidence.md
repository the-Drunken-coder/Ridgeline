# Evidence promotion checks, issue #100

Date: 2026-10-05 UTC.

Spec: `.scratch/pr-92-agent-environment/spec.md`, acceptance criterion 12. Ticket: https://github.com/the-Drunken-coder/Ridgeline/issues/100.
Integration owner: Root coordinator, combined verification #101.
Reviewed: scoped change `7699db6c9d16e6483ea36e1f21923d1988bdf677...016d1c7`, own diff reviewed for unintended changes.
Local verification: `8622ef71300d4b2ceea7fe89c7322826a0d1e3ab` in `/tmp/ridgeline-93-evidence`, clean source checkout. This merge includes integration tip `2df316afb75c39a6e9887a4c5e06a93af61563f0`; imported #94/#95 changes remain root's combined-review responsibility.
Hosted verification: None for this slice. No PR was opened or linked by this worker.

## Delivered behavior and guidance

`scripts/promote-evidence.mjs` takes an explicit JSON plan. It snapshots selected ignored/untracked regular files under resolved `.artifacts/`, rejects symlink ancestors and escaped paths, copies curated records, archives raw reports, verifies extracted bytes against producers and recorded SHA-256 values, and checks retained relative Markdown links/headings. A successful command publishes only into a new feature evidence directory. `--dry-run` performs the same verification in ignored staging, then removes only that unique staging directory. Neither command alters producers, releases pins, or runs the recorded runtime checks.

`docs/evidence-promotion.md` defines final reviews, compact revision/check provenance, readable summaries, selected visuals, raw report archives, member hashes, and reproduction instructions. `docs/agents/issue-tracker.md` now distinguishes deliberately versioned research/decision evidence from transient experiments and points to the workflow. Existing historical evidence, runtime inputs, regressions, and Git history are untouched.

The guide matches the #95 resource policy: recognized browser/measurement run directories use `.pin` for selected output; failures are automatically pinned; selected pins remain until successful verification and explicit owner release. Active/interrupted/unknown ownership, tracked/nonignored/symlink paths remain protected. `.artifacts/validation/` is outside automatic cleanup. The helper itself never prunes source runs.

Root should link `docs/evidence-promotion.md` from its README/CI guidance and perform the actual integrated closeout promotion after final review. These worker changes do not promote a final feature record prematurely.

## Executed checks and failure history

The agreed filesystem/process seam was exercised with real temporary Git checkouts, files, subprocesses, and `tar`, without source-text assertions or mocked archive behavior. The TDD history began with the missing command, then RED/GREEN cycles demonstrated and corrected symlinked sources, destination traversal, ignored source traversal outside `.artifacts`, explicit tracked-source diagnostics, malformed null entries, and retained links depending on transient output. The broken-link preservation case also executed the failure path after archive creation.

At final checkout `8622ef7`, `node --test scripts/promote-evidence.test.mjs` passed all 8 cases. It proves:

- Dry-run verification creates no versioned destination and removes its own staging; publish preserves raw member bytes, a known independent SHA-256 for `abc`, selected binary bytes, provenance, and the source pin.
- Intermediate output stays ignored while the curated destination is versionable. An existing destination is rejected without overwriting its summary.
- Symlink, destination escape, ignored source escape, tracked input, null entry, missing retained link, and transient retained-link failures publish no partial evidence and preserve producer files/pins.

`node --check scripts/promote-evidence.mjs` and `git diff --check` pass. Five actual relative documentation links and heading fragments resolve. The initial local documentation scan incorrectly counted an inline-code tracker template as a real link; excluding code examples resolved that scanner false positive without changing the historical tracker template.

Raw producer output for the 8 cases is `/tmp/ridgeline-93-context/promotion-tests.log`.

## Actual producer-log dry run

Command at `8622ef7`:

```sh
node scripts/promote-evidence.mjs .artifacts/evidence-promotion-proof/plan.json --dry-run
git check-ignore .artifacts/evidence-promotion-proof/intermediate.log
test -f .artifacts/evidence-promotion-proof/.pin
test ! -e .scratch/pr-92-agent-environment/evidence/promotion-dry-run
```

The explicit plan retained three curated records, including the completed parser/entity worker evidence, and four actual producer logs. All four raw archive members compared equal to the producer files after extraction; six retained links resolved. The planned destination remained absent. The source `.pin` and unselected `intermediate.log` remained unchanged and ignored. Producer output is `/tmp/ridgeline-93-context/promotion-dry-run.log`; it records verified raw archive SHA-256 `188be015ea113ddf535c0b46475c15a15e4a3c7c8323ee87fab2765cf6daade0`. Dry-run staging was intentionally discarded after verification.

The ignored source plan and exact input copies remain in `/tmp/ridgeline-93-evidence/.artifacts/evidence-promotion-proof/` for root inspection. Each source is pinned for handoff, not selected for deletion.

| Original producer member | Verified source SHA-256 |
| --- | --- |
| `parser-tests.log` | `ff4a2bfd24e50f7922e09f1a626f1befb45e748a110f2a114a0d3deff6d5e886` |
| `entities-module-tests.log` | `31b4ff68823ee36f48c672237b027c421dd64790f22ab829ccc3d24aff18b9bd` |
| `entities-browser-tests.log` | `0f3bdc3e130ae6edbe6910fb99833336f6d1254742e1ad745c17fc07202add56` |
| `promotion-tests.log` | `c1ad558a67fddc32483bc23a8acae675567336826e5ff2939554c1617ffaece5` |

The plan identifies parser/entity runs as dated historical evidence at their recorded worker revisions. Only the promotion subprocess checks were freshly executed at `8622ef7`. The retained byte counts and member hashes come from the exact snapshots; compression changes no producer content.

## Remaining limits

- Actual integrated evidence promotion, interaction with the combined retention delivery, independent Standards/Spec review, and the shared #101 closeout remain root's work. This slice establishes the tool and closeout contract, not merge readiness.
- The helper validates selected bytes and ordinary relative Markdown file links/headings. Remote URLs, non-Markdown references, and the truth/completeness of provenance claims need reviewer inspection. It does not parse or reinterpret raw producer formats.
- Producers must be quiescent and selected runs pinned before promotion. The helper compares snapshots with producer bytes but does not provide a competing run-lock mechanism or promise an atomic snapshot of actively changing output.
- Tests used installed Node/Git/tar on Linux. No hardware/browser matrix, fresh parser/entity runtime run, full runtime suite, or hosted check was performed by this curation slice.
