# Resource review fix evidence

Recorded 2026-10-05 17:19 UTC. Root remains the integration owner for #101.

Reviewed baseline: `83abbd8315e9121fce9c2940ad6623e614709f2a`. Scoped commits: `215a5b0e3feb6eb18b05e618d1efb6213d5b1b8f` and `ee49a4b4b6df0526b06a2576b50e39307a8c57ae`. Reviewed and exercised final head: `ee49a4b4b6df0526b06a2576b50e39307a8c57ae`. Checkout: `/tmp/ridgeline-93-review-fixes`, branch `implement/93-review-fixes`, clean tracked inputs. Current root integration `83abbd8` was merged before final checks and was already an ancestor.

Owned files are `scripts/browser-resources.mjs`, `scripts/test-browser.test.mjs`, and the integrated real-owner fixture in `scripts/promote-evidence.test.mjs`. No root edits, PR, push, tracker writes, or actual browser runs were performed.

## Demonstrated failures and corrections

The independent Standards probe deleted a recognized ignored completed record whose PID was text, start time was false, and invocation was null. The initial permanent subprocess regression also lost producer bytes for a missing PID. Retention now accepts only version/owner/command/status and metadata matching the real producer: positive safe integer PID, nonempty executable with string arguments, canonical ISO start/completion dates, and completion no earlier than start. Invalid or incomplete records remain protected. The regression preserves 23 malformed metadata variants while normal real-owner runs remain bounded.

A real-owner clock fixture showed that lexicographic sorting mishandled a canonical extended-year date and deleted the newest completion. Retention sorts parsed completion timestamps. The same fixture now retains the correct newest three records.

The independent snapshot probe produced `failure.log` plus a harmless nested symlink. The previous owner pinned an empty failed record, released its lock, and allowed the next run to overwrite the only producer evidence. Present protected output now throws an explicit retention error. Existing finalization retains the checkout lock. Missing output remains permitted when setup never produced it. Subprocess regressions for nested symlink and tracked output prove intact producer bytes and external targets, pinned failed ownership, refusal of subsequent setup, and recovery only after explicit owner evidence preservation, protection resolution, and lock release.

Review of commit `215a5b0` found valid empty trailing process arguments were over-rejected. The copied-wrapper regression was RED at `215a5b0`: six real completed unpinned records remained instead of three. Commit `ee49a4b` requires only the executable to be nonempty and allows empty later string arguments. GREEN retains exactly the newest three producer reports, deletes the oldest record, and verifies all six forwarded Playwright commands preserve `--grep` and its empty value. Malformed invocation `['']` remains protected. The separate Standards real-helper subprocess probe also now reports three complete records with preserved empty arguments.

The integrated promotion fixture now retains actual running/interrupted ownership records written by `claimBrowserRun`, instead of fabricated partial metadata. No child work is started for these fixture owners; the fixture explicitly releases its own locks while preserving their unfinished records. Promotion hashes/archive bytes, failure pins, explicit release, and curated evidence remain verified.

## Final executed checks at ee49a4b4b6df0526b06a2576b50e39307a8c57ae

- `node --test scripts/test-browser.test.mjs scripts/promote-evidence.test.mjs`: 30 passed, zero failures.
- `pnpm check`: passed, including ticket validation, root TypeScript check, and control-lab typecheck.
- `node --check` on all three owned JS files: passed.
- `git diff --check 83abbd8315e9121fce9c2940ad6623e614709f2a HEAD`: passed.
- `node /tmp/ridgeline-93-context/review-fixes-resource-probe.mjs`: malformed record preserved; failed snapshot rejected; lock retained; subsequent run refused; failed producer and external bytes unchanged.
- `node /tmp/ridgeline-93-context/standards-empty-argument-probe.mjs` in the owned checkout: five real helper completions retained only three, with empty trailing arguments preserved.

The owned checkout dependencies were installed from the local cache using `pnpm install --frozen-lockfile --offline`, after the Node-only disk preflight passed. An earlier shared-dependency-link setup caused pnpm's automatic install check to abort before removal. Those links were removed; final checks used the isolated installation. Root and the earlier dependency targets were not changed.

Raw producer logs and SHA256:

- `/tmp/ridgeline-93-context/review-fixes-tooling.stdout.log`: `5d394a2c0d3f2929979ca49f12def52dc7aaf52c1aca60ebb36b7bb93934ab5c`
- `/tmp/ridgeline-93-context/review-fixes-check.stdout.log`: `abd6b847b90a04c89ed0eefc5452eb314d77342815c044bf308da9b9129073c6`
- `/tmp/ridgeline-93-context/review-fixes-resource-probe.mjs`: `ddc9f022b59f63f8d64f97e981a2c6313317d01f653e8f1cece680715ffe4448`
- `/tmp/ridgeline-93-context/review-fixes-resource-probe.stdout.log`: `a8882ffb2fa6a2046b5ba9e686750d51f351571645c1a0e1d95d26ed70dc0e81`
- `/tmp/ridgeline-93-context/review-fixes-resource-probe.stderr.log`: `fd56456644ded728fde5c7ec176ad202e0a5c60f123eadc7cbc14b4c01dfd021`
- `/tmp/ridgeline-93-context/review-fixes-empty-argument-red.stdout.log`: `b31c473435903427c9f135f7280e5d5751d866440eb9df443110206578a39cef`
- `/tmp/ridgeline-93-context/review-fixes-empty-argument-green.stdout.log`: `fef889cc5dd9b7a0e1400c731113ec986fc345e2aecf18fe0ef8a3e168e8d037`
- `/tmp/ridgeline-93-context/review-fixes-empty-producer.stdout.log`: `89403555ac3322bb636a6b6feb2bd1a9c2095eb9637788c4a0588f9790e326ca`

## Limits

These checks exercise resource ownership and real filesystem/process boundaries with only expensive pnpm build/browser commands replaced at the external command boundary. They do not claim a new browser run, local full-validation run, or hosted validation at the final fix revision. Root's ongoing validation and hosted work pinned at `83abbd8` remain evidence for `83abbd8`, and require appropriate integration checks after this fix. Target hardware and the historical unexplained culling frame remain outside this fix.
