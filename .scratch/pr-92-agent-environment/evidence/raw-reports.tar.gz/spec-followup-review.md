# Spec follow-up review for #93 and #101

Date: 2026-10-05 UTC.
Reviewer: independent Spec-axis subagent `/root/spec_review`.
Canonical spec: `.scratch/pr-92-agent-environment/spec.md`.
Full base: `bf4cfca0ccaa7b781f7e3671d4982000bc9c3c50`.
Initial reviewed head: `83abbd8315e9121fce9c2940ad6623e614709f2a`.
Final reviewed and executed head: `ee49a4b4b6df0526b06a2576b50e39307a8c57ae`.
Checkout: `/tmp/ridgeline-93-review-fixes`, branch `implement/93-review-fixes`.
The final tracked checkout was clean before and after execution. No browsers, shared generated outputs, or tracked files were changed by this reviewer.

## Main report

**No remaining actionable Spec findings at `ee49a4b`.** The initial failure-capture finding is resolved: existing symlink-bearing or tracked capture output rejects finalization, retains the lock and original producer, and blocks replacement until the owner preserves the evidence. Executed recovery histories then captured the retained bytes and released ownership safely. This satisfies spec line 81: “keep required failure output available until it is retained or explicitly released.”

Completion metadata now protects malformed records and orders eligible records by actual completion time. The intermediate fix incorrectly rejected empty command arguments; an independent copied-wrapper reproduction demonstrated six unpruned runs at `215a5b0`. The final fix accepts empty argument values while requiring a nonempty executable. The same six-run history at `ee49a4b` retained exactly the newest three producer records.

The two corrective commits affect only the existing resource module and its process/promotion regressions. No unrequested scope or new incorrect requirement was demonstrated. Unchanged implementation hunks retain the initial full-diff investigation in `final-spec-review.md`; this reassessment investigated the changed guarantees and original objections rather than treating passing tests alone as a clean review.

This is an implementation review, not completed acceptance. Combined local validation, hosted results and actual tested checkout at the final integrated revision, actual final evidence promotion, and the shared thirteen-criterion record remain the integration owner's verification obligations. Checks at `83abbd8` remain pinned to that earlier head. Hardware/browser acceptance, the triangle guideline, and the historical unexplained culling frame retain their stated limits.

## Reviewed changes and ownership traces

```sh
git diff bf4cfca0ccaa7b781f7e3671d4982000bc9c3c50...ee49a4b4b6df0526b06a2576b50e39307a8c57ae
git diff 83abbd8315e9121fce9c2940ad6623e614709f2a..ee49a4b4b6df0526b06a2576b50e39307a8c57ae
git log 83abbd8315e9121fce9c2940ad6623e614709f2a..ee49a4b4b6df0526b06a2576b50e39307a8c57ae --oneline
```

The follow-up contains `215a5b0` and `ee49a4b`; only `scripts/browser-resources.mjs`, `scripts/test-browser.test.mjs`, and `scripts/promote-evidence.test.mjs` changed. The initial report investigated the remaining full-base diff. The canonical spec and domain/public contracts are unchanged.

Inspected callers and owners:

- `scripts/test-browser.mjs` and `scripts/test-browser-app.mjs` obtain the existing shared checkout lock before expensive work. Their real Playwright command sets capture ownership; an ordinary command failure reaches `finish(true)`. A capture rejection propagates as nonzero while `finalized` stays false, preserving the lock.
- `scripts/measure-models.mjs` still closes browser/server resources before finalizing. Its explicit `capture()` follows the successful verification producer write. Interruption and failed cleanup preserve ownership separately from ordinary successful finalization.
- `claimBrowserRun` writes real invocation/PID/start/status metadata. Finalization writes completion only after requested capture succeeds. Retention separately excludes pinned, tracked, nonignored, and symlink-bearing directories before checking completion metadata. Running/interrupted records cannot become eligible from parent absence.
- The validator accepts real argument values, including empty strings after the executable. It rejects incomplete ownership fields and noncanonical or reversed timestamps. Numeric ordering handles canonical extended-year ISO timestamps. No PID-liveness inference, extra lock system, or cache service was introduced.
- The promotion/retention integration regression now obtains running and interrupted records from the real producer rather than constructing incomplete lookalike metadata. Its explicit lock removal is limited to a no-child temporary fixture. The archive still compares producer bytes and remains intact after deliberate pin release and eligible cleanup.

## Executed focused checks at the final head

```sh
node --test scripts/test-browser.test.mjs scripts/promote-evidence.test.mjs scripts/test-measurement.test.mjs
git diff --check bf4cfca0ccaa7b781f7e3671d4982000bc9c3c50...ee49a4b4b6df0526b06a2576b50e39307a8c57ae
```

Both commands exited 0. The test command passed all 32 cases, including nested interruption and protection cases, with no failures, cancellations, skips, or retries, in 30.101 seconds. Raw producer output: `/tmp/ridgeline-93-context/spec-followup-final-tests.log`, SHA-256 `637b2c8ed32973453a536f783ab58289cc7851345ae9687cf5160ba3f082ebe4`.

The fixtures preserve real process/filesystem/Git/lock/archive boundaries. Only costly browser/build commands and explicit filesystem-capacity/date inputs are substituted. These executions establish tooling behavior; they do not establish model pixels or native browser teardown.

## Independent adverse histories and outcomes

| History | Executed outcome |
| --- | --- |
| After a run claims ownership, requested capture output gains a nested external symlink. | Finalization rejects; the original producer, external target, failed-run pin, running metadata, and shared lock remain. Another claim cannot replace the output. |
| Requested capture output gains a dangling nested symlink. | The same refusal and preservation occur. `lstat` recognizes the link even when its target is absent. |
| Requested fixed output itself becomes a symlink after ownership was claimed. | Finalization rejects and retains the lock. The linked producer and target remain unchanged. Resolving the protected path lets the original owner complete capture. |
| A producer file becomes Git-tracked after the run was claimed. | Finalization rejects rather than silently skipping it. The producer and index protection remain until the fixture owner explicitly resolves protection. |
| The owner resolves each protected capture path and retries finalization. | The retained producer is copied byte-exact into the pinned run; completion is recorded as failed only after capture; the lock releases. A later run succeeds while both archived producer bytes and external bytes remain intact. |
| Six actual copied packaged-wrapper processes forward `--grep ''`. | All exit 0, preserve the empty argument in invocation metadata, and retain exactly three complete unpinned records containing `producer 3`, `producer 4`, and `producer 5`. |
| Completion metadata omits or corrupts ownership/PID/invocation/start/completion fields, normalizes an invalid date, or completes before starting. | The process regression preserves all 23 malformed cases across repeated valid runs. Ordinary eligible history remains at three. Empty executable metadata remains malformed; empty later argument values remain legitimate. |
| Real producer dates cross canonical year 9999 into extended-year ISO format. | Numeric retention keeps the three latest actual completion times rather than lexical string order. |
| Browser commands overlap or a timed-out/signalled command leaves a real descendant alive. | Existing real-process checks still reject overlapping work, preserve interrupted ownership/output, and retain the lock. A missing parent does not grant cleanup ownership. |
| Pinned failure evidence is dry-run promoted, published, then deliberately released through the owner boundary. | Real producer records survive while running/interrupted; the pinned failure survives repeated cleanup; after explicit release only eligible old output is pruned. Curated archive bytes remain exact and its summary remains readable. |

The first five histories were independently executed with `/tmp/ridgeline-93-context/spec-capture-recovery-probe.mjs` against a `git show` copy of the exact final resource module. Command:

```sh
git show ee49a4b4b6df0526b06a2576b50e39307a8c57ae:scripts/browser-resources.mjs > /tmp/ridgeline-93-context/spec-resource-ee49.mjs
node /tmp/ridgeline-93-context/spec-capture-recovery-probe.mjs /tmp/ridgeline-93-context/spec-resource-ee49.mjs /tmp/ridgeline-93-context/spec-capture-recovery-ee49.json
```

Raw result: `/tmp/ridgeline-93-context/spec-capture-recovery-ee49.json`, SHA-256 `c292aac62c24f6dfd0c298168df4310002144be64b59a2159fd14cfed7f21e62`. The readable output and expected refusal messages are in `/tmp/ridgeline-93-context/spec-capture-recovery-ee49.log`.

The empty-argument history was independently executed through copied real wrapper/resource files from the clean final checkout, with only costly `pnpm` calls substituted:

```sh
node /tmp/ridgeline-93-context/spec-empty-argument-probe.mjs /tmp/ridgeline-93-review-fixes /tmp/ridgeline-93-context/spec-empty-argument-ee49.json --expect-three
```

Raw result: `/tmp/ridgeline-93-context/spec-empty-argument-ee49.json`, SHA-256 `00f83dba94b72174a63c3139053fd67ed487eeb6da14048ab3e4b3d71d420025`. The copied wrapper runs real processes, Git checks, filesystem capture, and retention; the fixture writes distinct producer bytes for all six iterations.

## Historical findings and remaining acceptance

The original `83abbd8` failure-capture reproduction and initial 64 focused checks remain in `final-spec-review.md`. The independent `215a5b0` empty-argument reproduction remains in `spec-empty-argument-probe.json`; all six successful complete records survived instead of the required three. Its original-capture recovery probe passed all four protection histories. Those intermediate observations remain historical and are not rewritten as successful final-head evidence.

This follow-up resolves both demonstrated Spec objections at `ee49a4b` and finds no further actionable Spec issue after tracing the callers, owners, and adverse histories above. It does not advance earlier browser/measurement execution pins. The integration owner still must check the combined final revision, inspect actual hosted results/checkout/measurement artifacts, promote the final actual evidence set, and map each criterion before resolving integrated acceptance. The unchanged hardware/browser/triangle and unexplained historical idle-frame limits remain explicit.

## Final Spec addendum at `361af95`

Date: 2026-10-05 UTC. Previous reviewed head `ee49a4b4b6df0526b06a2576b50e39307a8c57ae` is preserved above. Latest full review base remains `bf4cfca0ccaa7b781f7e3671d4982000bc9c3c50`; latest reviewed and executed checkout is `361af95d341c441e6d7598626d7bc5c51a62fcb7` in `/home/ubuntu/.t3/worktrees/Ridgeline/t3code-45512488`. The tracked checkout was clean before and after these checks. No browser was run by this reviewer, and no shared generated output or tracked file was changed.

### Main addendum report

**No actionable Spec findings in the three-file `ee49a4b..361af95` addendum.** The absent-model fixture uses the existing real Empty map scenario. I traced that action through consumer disposal, model unregistration, accepted feature clearing, and current entity/native publication retirement. It keeps the existing viewport/canvas. The positive visible-pixel result and real click occur first; the hidden panel and zero accepted features precede the unchanged empty-pixel settlement and 3-second absent rejection. The alpha/color/body threshold, coordinate conversion, actual observations, and fixture/setup/render budgets remain intact. The main workflow still exercises sample removal.

The 35-minute parent job permits the existing bounded 30-minute child plus setup/upload margin. The guarded `always()` upload is appropriate for existing screenshot/trace output after cancellation. It does not guarantee that a cancelled run produced a finalized blob or an artifact. The aggregate gate still rejects cancellation.

This is a focused implementation reassessment, with earlier investigations applying to unchanged hunks. The worker's production targeted case passed in 1.9 minutes on the exact committed source bytes; I independently ran 32 focused Node cases and parsed the workflow. Current full local validation, actual hosted results/checkout and cancellation-capture behavior, final promotion, and the shared criterion record remain root-owned verification. Earlier successful local `83abbd8` results and failed hosted run `37345459646` remain historical. The exact earlier fixture failure cause remains unknown; the change is not proof that repeated sample removal caused it. Hardware acceptance and the historical extra culling frame retain their separate limits.

### New investigation and evidence

Reviewed exactly:

```sh
git diff ee49a4b4b6df0526b06a2576b50e39307a8c57ae..361af95d341c441e6d7598626d7bc5c51a62fcb7 -- tests/playground/model-example.spec.ts .github/workflows/validation.yml docs/ci-validation.md
```

Only those three files changed. The canonical spec, observation helper, application implementation, viewport behavior, parser, resource owner, and permanent regressions outside this fixture remain unchanged.

Attempted histories were separated by execution boundary:

| History | Outcome and evidence boundary |
| --- | --- |
| Published model state arrives before screenshot pixels; the canvas is temporarily transparent. | Inspected unchanged positive fixture: the first actual screenshot must contain no body, restoration is delayed 750 ms, more than one observation is required, readiness requires more than 30 filled neighbors, and real pointer input must select a feature. The worker's targeted production execution passed these checks; this reviewer did not run a browser. |
| After successful pixel-based picking, the user selects the existing Empty map scenario. | Inspected `playground/main.ts:164-249`: consumer attachments are disposed, motion stops, the model panel hides, `viewport.clear()` removes all accepted IDs, selection clears, and the Empty branch adds no replacement samples. `mountModelExample.destroy` aborts fetch ownership, unregisters model definitions, releases listeners, restores visibility, and clears its panel. The existing singleton viewport and canvas are retained. No synthetic event, test-only public export, or new application behavior was introduced. |
| A retired model frame or native feature update finishes after the Empty transition. | Traced `src/viewport.ts:479-492` into entity retirement and native publication: accepted removal calls `EntityScene.set([], accepted)`, retires prepared model/state/choice/publication entries and terrain areas, invalidates labels/visibility, and queues current native removal. Earlier ownership/currentness guards remain unchanged. Crucially, the fixture does not stop at the zero-feature count: it waits for the existing screenshot criterion to become empty before its negative observation. This trace is inspection; focused publication/store checks below execute their existing ownership boundaries. |
| No model body appears during the negative readiness deadline. | Inspected unchanged 3000 ms `waitForVisible` rejection with the same greater-than-30 criterion; `absentObservations > 0` proves an actual completed screenshot observation occurred. The worker's production case passed this path. This reviewer reran the helper's never-completing-observation deadline regression. |
| A hosted playground child is cancelled or exhausts its bounded runner budget. | Inspected the unchanged `1_800_000` ms subprocess limit and new 35-minute parent limit. Existing interruption ownership remains. The screenshot/trace upload now has `always()` plus a file-presence guard; the blob upload already has `always()`. Official expression semantics support the guard, but no current hosted cancellation artifact availability is claimed by this review. |
| An incomplete hosted playground run reaches the required gate. | Executed the existing aggregate-gate fixtures at `361af95`: success alone passes; failure/cancellation/missing/skip reject. Inspected historical producer `hosted-first-gate.log`, which reports `Required validation did not succeed: playground-browser=cancelled`. |

GitHub documents that a step-level `always()` remains true on cancellation and that `hashFiles` returns an empty value when no files match. Thus the new expression permits existing output to upload after cancellation while skipping absent output. This conclusion concerns expression semantics, not a completed current hosted execution. [GitHub Actions expression reference](https://docs.github.com/en/actions/reference/workflows-and-actions/expressions).

The historical root log `.artifacts/issue-93/hosted-first-playground.log` records the absent-model case failure and later job cancellation, followed by a blob upload warning that no files matched. Its detailed failed interaction and screenshot/trace were unavailable. The earlier producer therefore establishes failed/cancelled validation, not a diagnosis of which repeated action failed. The new parent/upload settings do not retroactively recover that missing output.

Worker evidence was read from `/tmp/ridgeline-93-context/playground-review-fix-evidence.md` and its targeted stdout log. The targeted command ran on `ee49a4b` plus the three explicitly recorded modifications, then committed identical source bytes as `361af95`. This reviewer verified all three hashes against the clean committed checkout:

- `tests/playground/model-example.spec.ts`: `d885e6b22987c232971f1645a8aeee663482bbec761d9ec63ff18a5ae8122a67`.
- `.github/workflows/validation.yml`: `c818c4b11c35cb3d247a201e9a520868629d2b3448e5cd45e524b3b4c7dc960e`.
- `docs/ci-validation.md`: `75818cd2d481381cebe254d8c94a580c964fc3a96871d5cba6818f4a62068b33`.

### Executed checks and limits at `361af95`

```sh
node --test --test-name-pattern='measurement verification must succeed|gate only succeeds|local full validation' scripts/validation.test.mjs
node --import tsx --test tests/browser-observation.test.ts
node --import tsx --test tests/features.test.ts tests/feature-publication.test.ts
git diff --check ee49a4b4b6df0526b06a2576b50e39307a8c57ae..361af95d341c441e6d7598626d7bc5c51a62fcb7
```

The focused sets passed 4, 3, and 25 cases respectively, 32 total, with no failures, cancellations, or skips. Raw logs and hashes:

- `/tmp/ridgeline-93-context/spec-361-gate-tests.log`: `f5852a4bc186638d1e22cde5becc0846dbd93658fc19313deeb6bbaa26438e18`.
- `/tmp/ridgeline-93-context/spec-361-module-tests.log`: `fc25e37f54d089f32376a11be52991f96ed53a02cce8f2dc8a9c89d07f3c2bf0`.
- `/tmp/ridgeline-93-context/spec-361-clear-publication-tests.log`: `ffe3de02da4905e1b735d796737f6d53cfbe03a84e72f9c20863c0aa624d90e3`.

The observation command initially included a nonexistent `tests/feature-store.test.ts` argument. Node executed only the three observation cases. The correctly named `tests/features.test.ts` and publication tests were subsequently executed separately; the 32-case total counts actual reported tests, not the missing path. No source-text test was added. Python 3 parsed the workflow successfully and reported the 35-minute job and both artifact conditions. The unavailable `python` alias was replaced with `python3`; this syntax check does not execute GitHub Actions.

These are focused executable/inspection checks of the revised fixture's seams. They do not replace the current full integrated local run, complete hosted validation, actual hosted artifact inspection, or final byte-exact promotion. The previous `ee49a4b` report and its execution pins remain historical above; the latest clean implementation-review pin is now `361af95d341c441e6d7598626d7bc5c51a62fcb7`.
