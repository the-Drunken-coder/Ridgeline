import { readFileSync, existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fromMarkdown } from 'mdast-util-from-markdown';
const files=["README.md", "docs/support.md", "docs/ci-validation.md", "tools/model-measurement/README.md", ".scratch/airborne-entities/spec.md", ".scratch/entity-models/spec.md", ".scratch/entity-models/closeout.md", ".scratch/project-consolidation/plan.md", ".scratch/project-consolidation/mac-acceptance.md", ".scratch/project-consolidation/closeout.md", ".scratch/project-consolidation/evidence/final/README.md", ".scratch/project-consolidation/evidence/final/summary.md", ".scratch/project-consolidation/evidence/final/review.md"];
const cache=new Map();
function document(file) {
  file=resolve(file);
  if(cache.has(file))return cache.get(file);
  const nodes=[],pending=[fromMarkdown(readFileSync(file,'utf8'))];
  while(pending.length){const node=pending.pop();nodes.push(node);if(node.children)pending.push(...node.children.toReversed());}
  const definitions=new Map(nodes.filter(n=>n.type==='definition').map(n=>[n.identifier,n.url]));
  const text=n=>n.value??n.alt??n.children?.map(text).join('')??'';
  const headings=new Set();
  for(const node of nodes.filter(n=>n.type==='heading')){
    const slug=text(node).toLowerCase().replace(/[^\p{L}\p{N}_\-\s]/gu,'').replace(/\s/g,'-');
    let id=slug,duplicate=0;while(headings.has(id))id=`${slug}-${++duplicate}`;headings.add(id);
  }
  const links=nodes.flatMap(n=>n.type==='link'||n.type==='image'?[n.url]:n.type==='linkReference'||n.type==='imageReference'?[definitions.get(n.identifier)]:[]);
  const result={links,headings};cache.set(file,result);return result;
}
let verified=0;
for(const file of files)for(const link of document(file).links){
  if(typeof link!=='string')throw new Error(`Undefined link in ${file}`);
  if(/^[a-z][a-z0-9+.-]*:/i.test(link)||link.startsWith('//'))continue;
  const hash=link.indexOf('#'),path=decodeURIComponent((hash<0?link:link.slice(0,hash)).split('?')[0]);
  const fragment=hash<0?'':decodeURIComponent(link.slice(hash+1));
  const target=path?resolve(dirname(file),path):resolve(file);
  if(!existsSync(target))throw new Error(`Missing link in ${file}: ${link}`);
  if(fragment&&!document(target).headings.has(fragment))throw new Error(`Missing heading in ${file}: ${link}`);
  verified++;
}
console.log(JSON.stringify({files:files.length,verifiedLocalLinks:verified,result:'PASS'},null,2));
