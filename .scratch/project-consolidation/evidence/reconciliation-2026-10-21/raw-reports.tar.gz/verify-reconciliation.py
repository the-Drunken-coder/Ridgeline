import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile


def git(*args):
    return subprocess.check_output(['git', *args])


original = '0a9cf2e827a0b1a68928f86ae35f67d8314cbd2c'
main = 'e197fe92138ed90576e1804bc2ed72e9278fd97d'
base = '482d16433a91f6cdf7dc67d57a3763d84d59abce'
parser = argparse.ArgumentParser()
parser.add_argument('--evidence-dir', type=Path, default=Path('.artifacts/project-consolidation-reconciliation'))
inputs = parser.parse_args().evidence_dir
assert git('rev-parse', 'origin/t3/assess-project-alignment').decode().strip() == original
assert git('rev-parse', f'{base}:src') == git('rev-parse', f'{main}:src')
git('diff', '--exit-code', original, '--', 'src', '.scratch/airborne-entities/spec.md')
git('diff', '--exit-code', main, '--', '.github', 'scripts', 'tests', 'package.json', 'pnpm-lock.yaml')
subprocess.check_call(['git', 'merge-base', '--is-ancestor', main, 'HEAD'])
assert not git('rev-list', '--min-parents=2', f'{main}..HEAD').strip()

evidence = Path('.scratch/project-consolidation/evidence/final')
hashes = {}
for file in sorted(evidence.iterdir()):
    current = file.read_bytes()
    assert current == git('show', f'{original}:{file.as_posix()}'), file
    hashes[file.as_posix()] = hashlib.sha256(current).hexdigest()

for name in ['plan.md', 'closeout.md', 'mac-acceptance.md']:
    path = Path('.scratch/project-consolidation') / name
    historical_body = git('show', f'{original}:{path.as_posix()}').decode().split('\n', 1)[1]
    assert historical_body in path.read_text(), path

with tarfile.open(evidence / 'raw-reports.tar.gz', 'r:gz') as raw:
    original_package = raw.extractfile('runtime-package.tgz').read()
fresh_package = (inputs / 'tested-package.tgz').read_bytes()


def built_files(package):
    with tarfile.open(fileobj=io.BytesIO(package), mode='r:gz') as archive:
        return {member.name: archive.extractfile(member).read() for member in archive.getmembers()
                if member.isfile() and member.name.startswith('package/dist/')}


original_built = built_files(original_package)
assert original_built and original_built == built_files(fresh_package)
module_log = (inputs / 'module-validation.log').read_text()
browser_log = (inputs / 'focused-browser.log').read_text()
node_count = int(re.search(r'^ℹ tests (\d+)$', module_log, re.M)[1])
assert node_count > 0
assert int(re.search(r'^ℹ pass (\d+)$', module_log, re.M)[1]) == node_count
assert re.search(r'^ℹ fail 0$', module_log, re.M)
control = re.search(r'Tests\s+(\d+) passed \((\d+)\)', module_log)
assert control and control[1] == control[2] and int(control[1]) > 0
running = int(re.search(r'Running (\d+) tests using', browser_log)[1])
passed = int(re.search(r'^\s+(\d+) passed \(', browser_log, re.M)[1])
assert running == passed and passed > 0
package_check = json.loads(re.search(r'Validated final package: (\{[^\n]+\})', browser_log)[1])
with tarfile.open(fileobj=io.BytesIO(fresh_package), mode='r:gz') as package:
    members = [member.name for member in package.getmembers() if member.isfile()]
assert len(members) == package_check['files']
assert sum(name.endswith('.md') for name in members) == package_check['markdownFiles']
context = json.loads((inputs / 'validation-context.json').read_text())
git('diff', '--exit-code', context['revision'], '--', 'src', 'README.md', 'docs/support.md',
    'docs/performance.md', 'GLOSSARY.md', 'docs/viewport-tools.md', 'docs/adr', 'examples/starter',
    'package.json', 'pnpm-lock.yaml')
validation = {
    'revision': context['revision'],
    'nodeTests': node_count,
    'controlLabTests': int(control[1]),
    'focusedPackagedCases': passed,
    'packageFiles': len(members),
    'packageMarkdownFiles': package_check['markdownFiles'],
    'verifiedPackageLinks': package_check['verifiedLinks'],
    'identicalRuntimeFiles': len(original_built),
    'freshArchiveSha256': hashlib.sha256(fresh_package).hexdigest(),
    'fullValidateRunThisReconciliation': False,
    'hardwareAcceptance': 'WAIVED / NOT PERFORMED',
    'historicalPartialMacFailuresPreserved': True,
    'hostedMacOSRunThisWorkspace': False,
}

result = {
    'result': 'PASS',
    'main': main,
    'originalPreserved': original,
    'preparedHead': git('rev-parse', 'HEAD').decode().strip(),
    'mainSourceEqualsOriginalBase': True,
    'preparedRuntimeAndSensorSpecEqualOriginal': True,
    'mainCIAndTestsAndPackageConfigurationPreserved': True,
    'historicalEvidenceSha256': hashes,
    'historicalPlanCloseoutAndHandoffBodiesPreserved': True,
    'mergeCommitsAdded': False,
    'validationDerivedFromRetainedLogsAndPackages': validation,
}
output = Path('.audit/project-consolidation/reconciliation/verification.json')
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
