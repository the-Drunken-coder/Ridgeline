import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const git = (...args) => execFileSync('git', args, { encoding: 'utf8' });
const paths = [...new Set([...git('ls-files', '-z').split('\0'), ...git('ls-files', '--others', '--exclude-standard', '-z').split('\0')])]
  .filter(path => /^(src|tests|scripts|playground|examples\/starter|control-lab)\//.test(path) || /^\.github\/workflows\//.test(path) || /^[^/]+\.(json|ts|mjs|ya?ml)$/.test(path)).sort();
const files = paths.map(path => ({ path, sha256: createHash('sha256').update(readFileSync(path)).digest('hex') }));
const result = { capturedAt: new Date().toISOString(), revision: git('rev-parse', 'HEAD').trim(),
  scope: 'Tracked and untracked runtime, tests and configs. Documentation and local specs excluded.',
  digest: createHash('sha256').update(JSON.stringify(files)).digest('hex'), files };
writeFileSync(process.argv[2], JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ revision: result.revision, digest: result.digest, count: files.length }));
