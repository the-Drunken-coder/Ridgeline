# Viewport workflow upgrades

Status: library and starter implemented and locally verified; playground replay control placement awaits the user's static mock choice.

Source: the user's 2026-10-11 instruction to implement the four recommendations from the competitor gap review, except publishing. Baseline: `cbef055b14fe218aa24611031c4ba1a9aa0ed540`. This work remains local. Package publication, hosted documentation, tracker publication, and a pull request are excluded by the user's publishing constraint.

## Scope

1. Dependable adoption: runnable starter recipes, an API guide, a browser and input support matrix, repeatable accessibility and hardware checks, and dated evidence distinguishing tested support from outstanding hardware acceptance.
2. Everyday workflows: optional additive and rectangle selection, configurable label/icon/line/highlight presentation, coordinate helpers, and a standard map control attachment.
3. Drawing: edge snapping, exact individual segment length/bearing, creation and editing of polygon holes, and touch placement/editing with usable map navigation.
4. Motion: optional timestamped trajectories, interpolation, bounded trails, camera following, and playback controls for pause, seek, rate and replay.

These are the four recommendations, not every capability listed in the competitor report. Full GIS reprojection, multipart/collection geometry, tiled cities/BIM, new model formats, analysis engines, and database/network services are separate projects.

## Ownership and compatibility

- Consumers retain authentication, networking, persistence, permissions, historical storage, and accepted-change undo. Existing viewport and drawing APIs remain usable without the new attachments.
- All new attachments have explicit destroy methods, release their own listeners and scheduled work, and automatically retire with their viewport. They tolerate repeated destruction and partial setup.
- Use direct MapLibre integration for its standard controls. Do not duplicate its camera engine or introduce a renderer abstraction.
- Motion is optional map presentation over consumer-supplied samples. It supersedes the airborne spec's initial deferral of interpolation and playback. Route authoring, external time sources, saved history, and persistence stay consumer-owned.
- Polygon holes extend the version 1 drawing shape metadata additively. Old single-ring drawings retain their meaning. Geometry and shape definitions continue to round trip together under ADR-0003.
- APIs validate and snapshot inputs before accepting mutations. Reads return snapshots. Invalid input does not partly replace accepted state. Use existing diagnostics for callback failures, with bounded bookkeeping.

## Selection and presentation

- Keep existing selection behavior by default. An explicit multi-selection option enables Shift-click toggling and an explicit box-selection gesture. Consumers still receive selection requests and decide whether to apply them.
- Box selection must not interfere with default MapLibre box zoom, active drawing, controls, or ordinary camera navigation. A documented modifier chooses its ownership. Escape, blur, pointer cancellation, and ownership replacement clear transient rectangle feedback.
- Rectangle results use displayed selectable features and deduplicate entity/attachment hits to feature IDs. Results preserve stable order. Recheck data and ownership before requesting selection.
- Custom 3D rectangle queries conservatively intersect accepted projected geometry and model boxes. They can include geometry occluded by terrain and empty model-box space; GPU coverage approximates terrain draping with published nonzero-alpha texel spans. Document these limits. Ordinary and additive point picking share the existing terrain-depth rejection and ordering.
- Ordinary feature updates during a box drag keep the gesture active. Resolve current displayed representations on release so moving entities remain group-selectable. Camera, projection/style, resize and ownership changes still cancel the screen-space gesture.
- Add label font, size, color, halo and anchor/offset configuration; icon size, rotation and anchor; line dash arrays; and optional selection/hover appearance. Document units and renderer/font availability.
- Styles preserve the existing failure isolation and last accepted display behavior. New fields work for native markers and model labels where applicable. Selection/hover changes require no feature replacement.

## Coordinates and map controls

- Provide typed decimal-degree, degrees/minutes, and degrees/minutes/seconds formatting and parsing. Coordinate order is longitude then latitude. Reject malformed, nonfinite, and out-of-range values; handle hemisphere signs, rounding carry, negative zero and the date line deliberately.
- Provide geographic distance/bearing/destination helpers or document reuse of the existing spherical model. Do not imply survey-grade accuracy or silently convert coordinate reference systems.
- A standard optional attachment installs MapLibre navigation, scale, fullscreen and opt-in geolocation controls with configurable positions. Consumers can select a subset and use the original MapLibre options. No geolocation request occurs until the user triggers it.
- Coordinate readout and basemap choices may be included as optional controls, use accessible labels, and refresh from current map/configuration state. Dispose only controls owned by the attachment.

## Drawing behavior

- Existing vertex snapping remains available. Edge snapping is opt-in, uses a CSS-pixel tolerance and visible eligible feature segments, and honors `canSnap` and Alt bypass. Vertex hits win over edge hits at equal practical distance. Resolution validates terrain and the current scene after callbacks.
- Exact segment controls hold the start vertex fixed and move the end vertex to the supplied horizontal spherical distance and clockwise-from-north bearing. They work for line, arrow, polygon exterior and hole edges. Each committed field change is one draft undo step.
- Polygon shapes may have interior rings. Imported hole geometry is preserved on edit. Users can add, select, reshape and delete holes, with each operation inside the same draft and submission boundary.
- Holes must lie strictly inside the exterior, cannot intersect/touch the exterior or another hole, and cannot overlap/nest. Invalid drafts remain editable but cannot be submitted. Measurements subtract hole areas and include ring boundaries in perimeter. Translation moves every ring. No ring is silently dropped on reload.
- Touch uses explicit Finish/Cancel rather than double-tap completion. Tapping adds a point, dragging a handle changes it, and map gestures remain available with two fingers. Multi-touch, pointer cancel, capture loss, permission loss and camera movement settle a partial gesture without stale placement or movement. Mouse and keyboard behavior remains intact.
- Touch hit targets are usable without making the visible geometry handles obscure the map. Pending, rejected, conflict and forbidden states retain their existing contract and accessible feedback.

## Motion behavior

- A small optional controller takes timestamped Point feature samples and displays the interpolated current point through the viewport. Sample timestamps use milliseconds and must be ordered or normalized deterministically; duplicate times have a documented replacement policy.
- Interpolate along the shortest geographic path across the date line. Interpolate heading across its shortest angular path and altitude only when its reference is compatible. Missing altitude is not zero. Do not invent future positions when samples stop; hold the endpoint.
- Consumers can set/append/replace samples, pause/play, seek within retained bounds and set a positive finite playback rate. Finite replay stops at its end and can restart explicitly. Expose a snapshot state and change subscription for replacement controls.
- Retained samples and trails are bounded by documented limits. Trail visibility and duration are configurable. Trail resources do not overwrite consumer feature IDs and are removed on removal/destruction.
- Following centers on the displayed position without changing zoom/pitch/bearing. Manual camera navigation releases follow so the controller does not fight input. Removing a followed track releases follow. Drawing interaction ownership suspends or releases following before it can invalidate a gesture.
- Schedule frames only while playback can advance. Paused/end/empty controllers perform no continuous work. Reentrant consumer observers that seek, replace samples, pause or destroy retire the prior operation before it can publish or schedule again.

## UI contract

Keep the approved Field desk surrounding UI, Map bench picker, and labeled drawing rail/fixed inspector. Add dense labeled fields and useful state text using existing green/neutral tokens. No decorative cards, pills, idle animation, or application-specific workflows in the library. Replay placement is the only new visual choice: sidebar controls or a bottom timeline. Implement that choice after the user selects a static mock.

At narrow widths, controls reflow into readable rows rather than shrink text. All visible controls have a real outcome. Keyboard focus survives ordinary updates; state transitions use enabled fallbacks. Empty, pending, rejection, conflict, permission failure and unavailable resource states remain reachable.

## Acceptance and verification

- A separate packed-package consumer uses every new export and completes selection, styling, numeric drawing, hole save/reload, touch editing, motion seek/follow and teardown workflows.
- Focused geometry/state tests cover invalid inputs, date-line interpolation and snapping, heading wrap, compatible altitude, hole validity/measurements, exact segment edits, bounded storage and stopped scheduling.
- Native browser input verifies additive/box selection, touch placement/drag/cancellation and two-finger navigation, keyboard controls, focus continuity, follow release and one action per shortcut.
- Starter recipes build against the packed package. Their scope and storage ownership are explicit. README documents every public addition and links focused guides.
- Browser results and accessibility observations are dated and revision-pinned. Chromium, Firefox and WebKit runs establish only the exercised environment. Hardware/GPU performance requires its repeatable target-hardware run; do not infer it from software rendering.
- Root is the integration owner. It reviews the combined diff and records reviewed/exercised inputs in `closeout.md`. Uncommitted changes are identified explicitly. No merge-ready or hosted-check claim without hosted verification.

| Transition | Owner | Observable result | Verification |
| --- | --- | --- | --- |
| Gesture gains/loses ownership or camera/scene changes | Selection and drawing attachments | Transient targets retire; later valid input works | Real pointer/keyboard/touch workflows |
| Callback changes owner, samples, draft or data | Current attachment/controller | No obsolete publication or later mutation | Reentrant public-interface histories |
| Hole or numeric segment edit is accepted/rejected/undone | Drawing session; consumer on acceptance | Complete rings retained; draft history and submission coherent | Geometry tests and packed save/reload workflow |
| Seek/rate/pause/end/replacement during playback | Motion controller | Current point/trail match clock; idle stops scheduling | Controlled clock and packed consumer |
| Manual camera input or active drawing while following | Motion controller | Following releases/suspends before competing mutation | Native camera and drawing input |
| Destroy/remount, including inside an observer | Each attachment, root integrates | Old resources/work disappear; replacement usable | Packed consumer lifecycle workflow |

## Work ownership

- Selection/presentation worker owns `src/types.ts`, `src/viewport.ts`, `src/interactions.ts`, `src/model-labels.ts`, related presentation modules if required, and a focused new browser helper. It must coordinate any cross-owner need before editing.
- Drawing worker owns `src/drawing*.ts`, `src/drawing-geometry.ts`, `src/drawing-shapes.ts`, drawing-specific tests and a focused new browser helper. It can read viewport internals but requests changes from the selection/presentation owner.
- Motion worker owns new `src/motion*.ts`, motion tests and a focused new browser helper. It does not edit shared exports, types, stylesheet or playground integration.
- Root owns coordinates, standard controls, exports, CSS, playground integration, recipes, docs, support checks, browser registration/configuration and combined validation.

Local working tickets intentionally remain unpublished under the user's constraint. They contain the tracker adapter's metadata and share one integration closeout record.
