# Viewport upgrade closeout

Recorded 2026-10-11. These are uncommitted local changes on `t3/research-project-competitors`. Nothing was published, pushed, committed, deployed or opened as a pull request.

Spec: [Viewport workflow upgrades](spec.md)
Integration owner: root
Reviewed: baseline and HEAD `cbef055b14fe218aa24611031c4ba1a9aa0ed540`, plus the uncommitted inputs recorded below
Local verification: current results below; prior runs are historical evidence for their own inputs
Hosted verification: excluded by the user's publishing constraint; no hosted or merge-readiness claim
Remaining limits: physical devices, installed browsers, target GPU performance and manual screen-reader acceptance remain pending

## Current scope and ownership

- Optional additive/rectangle selection, rectangle queries and configurable labels/icons/dashes and selected/hover appearance.
- Standard MapLibre controls, map-center coordinates, DD/DDM/DMS parsing/formatting and spherical distance/bearing/destination helpers.
- Polygon holes, exact segment distance/bearing, optional visible-edge snapping, touch placement/editing and interrupted-gesture recovery.
- A packed-package TypeScript starter with selection/styling and drawing/storage recipes, public guides and a three-engine support CI job.

The user withdrew motion and replay on 2026-10-11. The new sample-history/interpolation/playback/trail/follow controller, public exports, controls, CSS, demo and tests have been removed. Application data, history, clocks, interpolation, retention, replay and camera-follow policy belong to consumers. Ridgeline accepts complete current features through `upsert`, retires displayed features through `remove`/`clear`, and accepts chosen camera changes through `setCamera`. The existing consumer-owned moving/airborne examples remain intact. Viewport snapshots and drawing drafts are current display and interaction state.

Drawing retains the approved rail and fixed inspector. No replay layout choice is pending. The [withdrawn motion ticket](issues/03-motion.md) records historical criteria; it is not an open implementation dependency.

## Reviewed and exercised inputs

The baseline/HEAD is `cbef055b14fe218aa24611031c4ba1a9aa0ed540`. Input manifests hash every tracked and untracked runtime, test and config file. A commit SHA alone does not identify these uncommitted changes.

| Input set | SHA-256 digest | Evidence |
| --- | --- | --- |
| Initial removal | `2e06f96de6a714b7ccde12b4db24157020bb60c24e0e26790d5b64fa27d78d05` | Typechecks, 424 library/tooling tests and 5 control-lab tests passed. Support passed 30/33; each engine reproduced the starter's stale selection label on mode switch. |
| Explicit consumer reset selection | `50853a463fee75ff3edc4a75d7332ba42388a588c263b0893256a7253977d46e` | Final typechecks, 33 support cases, 3 packaged consumer update/touch cases and playground production build passed. |

The current input list contains 182 files. Compared with the previous delivered input, ten motion-related files were removed, eleven integration/recipe/test files changed, and 171 files are byte-identical. After the first removal run, only starter `main.ts` changed: reset now explicitly chooses an empty selection after clearing displayed features. This fixes the stale application label without changing core selection events or data policy.

## Current checks

| Command | Inputs | Result |
| --- | --- | --- |
| `pnpm check` | Initial removal and final | Ticket validation, root TypeScript and control-lab TypeScript passed. |
| `pnpm test` | Initial removal | 424 library/tooling and 5 control-lab state tests passed. Final-only starter reset does not change their implementation inputs. |
| `pnpm test:support --reporter=list,json` | Initial removal | 30/33 passed; all three engines reproduced the stale starter selection label. Failed logs/reports remain retained. |
| `pnpm test:support --reporter=list,json` | Final | 33/33 passed, 11 each in Chromium/Firefox/WebKit, no skips or retries. Builds and installs a fresh local package; starter declarations and production build pass. |
| `pnpm test:browser --grep 'Incremental updates replace data without moving the camera\|Picker candidates stay stable during movement\|Drawing upgrades touch' --reporter=list,json` | Final | 3/3 passed. Current feature updates preserve camera and selected identity; moving picker remains stable; native touch placement, handles, cancellation and two-finger navigation pass. |
| `pnpm build:playground` | Final | Library/declarations and playground production build passed. |
| `pnpm measure` | Final and clean baseline | Library plus CSS adds 40,651 raw and 11,218 gzip bytes over baseline, with no new library dependency. Motion removal saves 6,499 gzip bytes compared with the earlier upgrade build. |

Final before/after runtime manifests have the same digest. Root inspected the desktop and narrow drawing screenshots. Numeric fields remain readable, the rail/inspector retain their approved direction, and the narrow layout has no horizontal overflow. No new manual device acceptance is claimed. The unchanged playground/control-lab journeys and measurement tooling retain their earlier successful, dated evidence; they were not rerun for this removal.

## Review and acceptance

Root owns integrated verification and reviews the combined diff. Independent review found no outstanding Standards or Spec code findings for the removal and starter scope and independently verified all 182 final input hashes. Root confirmed the fixes and reviewed the combined delivery. The current review traces removal through exports, declarations, package preparation, browser registration, styling and starter teardown. Public docs use the actual `upsert`/`remove`/`clear` API; an inaccurate `setFeatures` reference was corrected without adding an API.

Selection/presentation and drawing acceptance retain their previous focused/broad evidence for unchanged implementation. Current three-engine support verifies their installed-package integrations again. Touch placement/drag/cancellation/two-finger navigation has prior native Chromium dispatch evidence; physical devices remain unverified. The revised starter verifies save/reopen of numeric segments, native Tab/Enter focus, 390 CSS px layout and attachment disposal on mode switch.

The motion criteria are withdrawn, not satisfied by a replacement controller. Consumer-owned movement is verified through existing feature updates, stable identity/selection, camera independence and moving picker behavior. Prior evidence is preserved below.

## Historical evidence before scope correction

The [earlier curated record](evidence/final/README.md) describes the now-withdrawn motion/replay implementation and its original inputs. Its files, review, screenshots and raw archive remain unchanged. Historical reports do not describe current motion APIs or a pending layout choice.

The earlier input digests were `9aa3b1727c1a4e2564622266a2996199f22e85e024a28b5990f1bafe7eb8aa1c`, `16581104a0a5a150d7244d689723b5924703ccf415e636adbce9e53666a886b0`, `8a39dd2e64696e3751ddd5f1c0738d644d38024cecd80c24a228462b377c59b1`, and final `8ccbe6759d8f309c98902d8c115fceed111215cb16150d00004a2a2621c39b66`. That work passed 440 Node tests, 42 focused support cases, 6 playground journeys, 5 control-lab journeys, both builds and measurement tooling at their recorded inputs. Its initial broad Chromium run passed 198/199 and stopped at an old inspector Tab assertion; the corrected case passed across three engines. No successful single-command `pnpm validate` run was claimed.

Its byte-exact raw archive has SHA-256 `dff662b655df7df2f5762a37d8ea80bdeb0671df5457c7ee3add91baec257421` and 269,654 bytes. The prior closeout is retained in the new raw archive alongside the scope correction. Earlier producers and failures remain pinned.

## Environment and limits

Ubuntu 24.04.5, Node 24.21.0, pnpm 11.0.9, Vite 8.3.0 and Playwright 1.63.0. Chromium 153.0.8010.12 uses ANGLE/SwiftShader; Firefox 155.0 runs under Xvfb with Mesa software rendering; Linux WebKit 26.6 reports a masked `Apple GPU` string. This host has no `/dev/dri`. These observations do not establish Apple hardware or installed Safari acceptance.

Physical Android/iOS, pen, installed browsers, hardware performance, manual VoiceOver/NVDA and long-session memory acceptance remain unverified. Prior T3 manual inspection reached the approved drawing scene and Edit action, then the native preview host became explicitly unavailable; that journey was not claimed complete. Rectangle custom 3D/model/GPU queries retain documented conservative approximations. Geographic helpers use a spherical model.

## Current evidence retention

The [scope-corrected evidence](evidence/consumer-owned-data/README.md) retains the root/independent review, summary, actual environment data, desktop/narrow drawing screenshots and a byte-exact raw report archive. Promotion verified five curated files, 21 raw report members and seven retained links. It copies evidence without rerunning checks or changing their pins.

```sh
node scripts/promote-evidence.mjs .artifacts/viewport-upgrades/consumer-owned-data/promotion-plan.json --dry-run
node scripts/promote-evidence.mjs .artifacts/viewport-upgrades/consumer-owned-data/promotion-plan.json
```

Raw archive SHA-256: `43d55882515b7253a87aab2e975687c5eda8811fe0067c27c138184ddfd2f6ea`, 482,576 bytes. Its manifest records member/file hashes and reproduction commands. The current support and update/touch producers and the reproduced failure remain pinned. Root reviewed promotion output, retained reports and links. Earlier evidence/final remains byte-identical and historical. All work remains unstaged and uncommitted.

Final documentation verification covered 23 changed/new Markdown files and 95 local file/heading links with no failures. Ticket and whitespace checks passed. The handoff runtime digest remains unchanged.
