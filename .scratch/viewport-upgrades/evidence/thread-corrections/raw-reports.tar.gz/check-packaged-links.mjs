import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { posix } from 'node:path';
import { createHash } from 'node:crypto';
import { fromMarkdown } from 'mdast-util-from-markdown';
const archive='.artifacts/ridgeline-map-0.1.0.tgz';
const entries=new Set(execFileSync('tar',['-tzf',archive],{encoding:'utf8'}).trim().split('\n'));
const read=file=>execFileSync('tar',['-xOf',archive,file]);
const failures=[];let checked=0;
const files=[...entries].filter(file=>file.endsWith('.md'));
for(const file of files){
 const source=read(file).toString();const pending=[fromMarkdown(source)],nodes=[];
 while(pending.length){const node=pending.pop();nodes.push(node);if(node.children)pending.push(...node.children);}
 const definitions=new Map(nodes.filter(node=>node.type==='definition').map(node=>[node.identifier,node.url]));
 const links=nodes.flatMap(node=>node.type==='link'||node.type==='image'?[node.url]:node.type==='linkReference'||node.type==='imageReference'?[definitions.get(node.identifier)]:[]);
 for(const link of links){
  if(!link){failures.push({file,reason:'unresolved reference'});continue;}
  if(/^[a-z][a-z0-9+.-]*:/i.test(link)||link.startsWith('//'))continue;
  checked++;const [target,fragment]=link.split('#');
  const path=target?posix.normalize(posix.join(posix.dirname(file),decodeURIComponent(target))):file;
  if(!entries.has(path)){failures.push({file,link,reason:'missing packaged file'});continue;}
  if(fragment&&path.endsWith('.md')){
   const headings=[...read(path).toString().matchAll(/^#+\s+(.+)$/gm)].map(match=>match[1].toLowerCase().replace(/[^\w\s-]/g,'').replace(/\s+/g,'-'));
   if(!headings.includes(decodeURIComponent(fragment)))failures.push({file,link,reason:'missing heading'});
  }
 }
}
const forbidden=[...entries].filter(file=>file.includes('/node_modules/')||file.includes('/.scratch/')||file.includes('examples/starter/dist/')||file.endsWith('pnpm-lock.yaml'));
if(forbidden.length)failures.push({reason:'unexpected generated/private files',files:forbidden});
const hash=data=>createHash('sha256').update(data).digest('hex');
const js=hash(read('package/dist/ridgeline.js'));
const declarations=hash(read('package/dist/index.d.ts'));
if(js!=='be52b6fdf4c67baceeb39749a28f170d504e370b7f7bf9def9a3d3a30d62d467'||declarations!=='da82ee58e95d838155fcc6e09084989b2a35e66060db19580fa0f416b194db9b')failures.push({reason:'runtime differs from standalone-tested archive'});
const result={capturedAt:new Date().toISOString(),archive,archiveSha256:hash(readFileSync(archive)),files:files.length,localLinks:checked,jsSha256:js,declarationsSha256:declarations,failures};
writeFileSync('.artifacts/viewport-upgrades/thread-corrections/packaged-links.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));if(failures.length)process.exitCode=1;
