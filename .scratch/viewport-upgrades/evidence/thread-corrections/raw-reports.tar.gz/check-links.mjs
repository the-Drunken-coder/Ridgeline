import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fromMarkdown } from 'mdast-util-from-markdown';
const git = (...args) => execFileSync('git', args, { encoding: 'utf8' });
const files = [...new Set([...git('diff','--name-only','HEAD').split('\n'), ...git('ls-files','--others','--exclude-standard','-z').split('\0')])]
  .filter(path=>path.endsWith('.md') && existsSync(path));
const failures=[]; let checked=0;
for (const path of files) {
  const pending=[fromMarkdown(readFileSync(path,'utf8'))], nodes=[];
  while(pending.length){const node=pending.pop(); nodes.push(node); if(node.children) pending.push(...node.children);}
  const definitions=new Map(nodes.filter(node=>node.type==='definition').map(node=>[node.identifier,node.url]));
  const links=nodes.flatMap(node=>node.type==='link'||node.type==='image'?[node.url]:node.type==='linkReference'||node.type==='imageReference'?[definitions.get(node.identifier)]:[]);
  for(const link of links){
    if(!link){failures.push({path,link:'unresolved reference'});continue;}
    if(/^[a-z][a-z0-9+.-]*:/i.test(link)||link.startsWith('//'))continue;
    const [target,fragment]=link.split('#'); const absolute=target?resolve(dirname(path),decodeURIComponent(target)):resolve(path);
    checked++;
    if(!existsSync(absolute)){failures.push({path,link,reason:'missing file'});continue;}
    if(fragment&&absolute.endsWith('.md')){
      const headings=[...readFileSync(absolute,'utf8').matchAll(/^#+\s+(.+)$/gm)]
        .map(match=>match[1].toLowerCase().replace(/[^\w\s-]/g,'').replace(/\s+/g,'-'));
      if(!headings.includes(decodeURIComponent(fragment)))failures.push({path,link,reason:'missing heading'});
    }
  }
}
const result={capturedAt:new Date().toISOString(),files:files.length,localLinks:checked,failures};
writeFileSync('.artifacts/viewport-upgrades/thread-corrections/links.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2)); if(failures.length)process.exitCode=1;
