# Viewport upgrade closeout

Recorded 2026-10-11. These are uncommitted local changes on `t3/research-project-competitors`. Nothing was published, pushed, committed, deployed or opened as a pull request.

Spec: [Viewport workflow upgrades](spec.md)
Integration owner: root
Reviewed: baseline and HEAD `cbef055b14fe218aa24611031c4ba1a9aa0ed540`, plus the uncommitted implementation identified below
Local verification: completed checks and distinct input pins below
Hosted verification: excluded by the user's publishing constraint; no hosted run or merge-readiness claim
Remaining limits: playground replay placement needs the user's static mock choice; physical devices, installed browsers and manual screen-reader acceptance remain pending

## Delivered scope

- Optional additive/rectangle selection, rectangle queries, configurable labels/icons/dashes and selected/hover appearance.
- Standard MapLibre controls, map-center coordinate display, DD/DDM/DMS parsing/formatting and spherical distance/bearing/destination helpers.
- Polygon holes, exact segment distance/bearing, optional visible-edge snapping, touch placement/editing and interrupted-gesture recovery.
- Optional sample interpolation, bounded trails, follow, play/pause/seek/rate and replay controls. Applications keep storage, networking and accepted-change history.
- A plain TypeScript starter using a freshly installed package, three recipes, the [public API guide](../../docs/viewport-tools.md), [support/reproduction guide](../../docs/support.md) and a required three-engine CI job.

The drawing rail and fixed inspector retain their approved direction. Library replay controls and the starter are implemented. `playground/replay.ts` prepares the consumer demo but is not mounted. The pending static choices are A, replay in the sidebar, and B, a timeline below the map. The supplied AGENTS instructions require presenting distinct static mocks and waiting for the user's choice before a substantial new visual direction. No elapsed time was treated as approval.

## Reviewed and exercised inputs

A commit SHA alone cannot identify this work because the implementation is uncommitted. The input manifests hash every tracked and untracked runtime, test and config file, including new modules. Their digest is SHA-256 of the sorted JSON file/hash list. Documentation and local specs are recorded separately from that runtime list.

| Input set | Digest | Use |
| --- | --- | --- |
| Initial broad run | `9aa3b1727c1a4e2564622266a2996199f22e85e024a28b5990f1bafe7eb8aa1c` | Initial check, tests and full Chromium run |
| Sparse motion fix and new tab-order assertion | `16581104a0a5a150d7244d689723b5924703ccf415e636adbce9e53666a886b0` | Repeated check and 440 Node tests |
| Integrated fixture placement | `8a39dd2e64696e3751ddd5f1c0738d644d38024cecd80c24a228462b377c59b1` | Three-engine support, playground, control lab, builds and measurement tooling |
| Final replay label layout and narrow journey | `8ccbe6759d8f309c98902d8c115fceed111215cb16150d00004a2a2621c39b66` | Final typecheck, nine affected browser cases, playground build and bundle measurement |

The unit-run file list was reconstructed from the next manifest by reversing only the inspector mount edit in memory. Its digest matches the originally recorded unit-run digest. The raw member states that method explicitly.

Root reviewed the combined delivery and the subsequent changes. Independent investigations covered selection/presentation, drawing and motion/control behavior. Confirmed sparse-array validation, hole world-copy, canceled feedback, observer recovery, overflow, error-context and cleanup defects were corrected. The [integrated review](evidence/final/review.md) records Standards and Spec findings separately. There are no outstanding confirmed code findings in the implemented library/starter scope. Playground replay placement is an explicit remaining Spec dependency.

The final runtime list contains 192 files. Before/after snapshots have the same digest. The final change from the integrated run is one replay label CSS declaration and the starter's additional narrow-screen keyboard/overflow journey. The affected UI and production build were repeated. Earlier broader checks verify the unchanged behavior they exercised.

## Check outcomes

| Command | Inputs | Result |
| --- | --- | --- |
| `pnpm validate` | Initial | Check passed; 439 Node tests and 5 control-lab state tests passed; Chromium 198/199 passed. The command stopped at an outdated inspector tab-order assertion. It is not a successful single-command validation run. |
| `pnpm check` | Sparse fix/tab order | Passed ticket validation, root TypeScript and control-lab TypeScript |
| `pnpm test` | Sparse fix/tab order | 440 Node library/tooling tests and 5 control-lab state tests passed |
| `pnpm test:support` | Integrated fixture placement | 42 cases passed, 14 each in Chromium, Firefox and WebKit; no retries |
| `pnpm test:playground:browser` | Integrated fixture placement | All 6 production playground journeys passed, including visible model picking, delayed pixel readiness, fetch cancellation, shared-model reset and drawing/sidebar actions |
| `pnpm test:controls:browser` | Integrated fixture placement | All 5 native control-lab journeys passed |
| `pnpm build:playground` and `pnpm build:controls` | Integrated fixture placement | Both passed |
| `pnpm test:measurement` | Integrated fixture placement | Existing report/workload/pixel checks and the packed-library instrumentation/ownership probe passed |
| `pnpm exec tsc --noEmit` | Final | Passed |
| Final support capture with JSON reporter | Final | All 9 affected cases passed across the three engines; no skips, failures or retries. Retains actual environment output and desktop/narrow screenshots. |
| `pnpm build:playground` | Final | Passed |
| `pnpm measure` and isolated baseline production build | Final and clean baseline | Complete library plus CSS adds 64,590 raw bytes and 17,717 gzip bytes; no new library dependency |
| `node scripts/check-tickets.mjs`, local Markdown link/heading check, `git diff --check` | Final documentation | Passed |

The final evidence capture command was:

```sh
PLAYWRIGHT_JSON_OUTPUT_FILE=.artifacts/viewport-upgrades/support-report.json pnpm test:support --grep 'Workflow controls|Adoption starter|Inspector label editing' --reporter=list,json
```

The broad Chromium failure was an old expectation that Stroke follows Label. The new Segment, Distance and Bearing controls intentionally come first. The revised test verifies that complete native Tab sequence and the first Finish click. Three-engine execution additionally exposed fixture controls clipped inside the map canvas. The fixture now mounts them outside the map, matching the starter and playground. Failed attempts remain retained; their results are not counted as passes.

The sparse-coordinate motion regression failed before the fix and passed after it. It tests both replacement and append with missing tuple entries and top-level sample holes. State, feature, frame identity, updates and notifications remain unchanged after rejection, and the original playback continues. Its focused 16-test run and TypeScript check also passed.

## Acceptance mapping

| Ticket criteria | Evidence | Status |
| --- | --- | --- |
| Selection opt-in, consumer requests and native navigation/drawing ownership | Optional selection and rectangle interruption cases in the support matrix; unchanged default input cases in the broad run | Satisfied |
| Validated/copied label, icon, line and feedback presentation; failed callback retains display | Focused style tests, model presentation and native feature presentation cases | Satisfied |
| Reentrant selection/style updates retire obsolete requests and display | Native callback/scene-change histories in the broad and support runs | Satisfied |
| Selection exports, CSS and consumer integration | Typechecks, fresh package install and public starter workflows | Satisfied |
| Edge snap visibility/tolerance/Alt/filter/current-scene behavior | Native edge case includes ordinary long GeoJSON and short saved date-line crossings | Satisfied |
| Numeric exterior/hole segments and one-step history | Drawing state/geometry tests and native exact-hole-segment save/reload case | Satisfied |
| Hole topology, translation, metadata and world-copy round trips | Focused geometry/session regressions and packed save/reload workflow | Satisfied |
| Touch placement, handles, interruption, permissions and two-finger navigation | Native Chromium touch dispatch in the broad run | Satisfied for emulated Chromium; physical devices pending |
| Existing submission/rejection/conflict/permissions/focus guarantees | Public drawing regressions plus three-engine inspector keyboard/first-click checks | Satisfied |
| Motion validation/copying, interpolation, endpoints and bounded history | 16 focused motion tests, including regression-failing sparse-input history; three packed motion workflows | Satisfied |
| Play/pause/seek/rate/trails and no continuous idle scheduling | Controlled clock tests and packed replay/trail workflow | Satisfied |
| Follow release and trail ownership | Native manual/external camera and drawing-ownership cases; trail teardown/style restoration | Satisfied |
| Reentrant observer/destroy safety | Public observer recovery/destroy histories and packed consumer-observer case | Satisfied |
| Replay controls and packed starter | Final three-engine keyboard/endpoint focus, narrow overflow and teardown journeys | Satisfied |
| Selected playground replay layout | Static mocks presented; user choice has not arrived | Pending; motion ticket remains `needs-info` |
| Adoption recipes, guide and reproducible engine/accessibility/hardware checks | Fresh package starter build, support CI fixture checks and documented acceptance procedures | Satisfied locally; physical/manual acceptance pending |

## Environment and limits

The host is Ubuntu 24.04.5 with Node 24.21.0, pnpm 11.0.9, Vite 8.3.0 and Playwright 1.63.0. [Environment data](evidence/final/environment.json) retains browser versions and reported renderers from a live viewport. Chromium 153.0.8010.12 reported ANGLE/SwiftShader. Firefox 155.0 ran under Xvfb and reported Mesa `llvmpipe, or similar`. Linux WebKit 26.6 reported `Apple GPU`; its masked renderer and Safari-like user agent do not establish Apple hardware or installed Safari support. `/dev/dri` is absent.

Root inspected the retained [desktop replay](evidence/final/replay-starter.png) and [390 px replay](evidence/final/replay-narrow.png) screenshots. Keyboard focus, phase status, follow controls, endpoint behavior, narrow overflow and teardown have automated native-input evidence. Manual playground inspection reached the approved drawing scene and Edit action, then the T3 preview host became explicitly unavailable. That manual journey was not claimed complete or replaced with another manual browser system.

Physical Android/iOS, pen, installed Safari/Chrome/Edge, hardware GPU performance, manual VoiceOver/NVDA, full accessibility certification and long-session memory acceptance remain unverified. Rectangle selection deliberately uses conservative custom 3D geometry/model-box intersections and GPU coverage span approximations; it does not promise mesh/pixel accuracy or terrain occlusion rejection. Ordinary/additive point picking retains depth rejection. Distance/bearing helpers use the documented spherical model.

## Evidence retention

The [curated record](evidence/final/README.md) includes review, summary, environment, selected screenshots, a manifest and a byte-exact compressed archive of original reports. Completed support/capture producers and failures remain pinned. Promotion copies evidence without re-executing checks or advancing input pins.

```sh
node scripts/promote-evidence.mjs .artifacts/viewport-upgrades/promotion-plan.json --dry-run
node scripts/promote-evidence.mjs .artifacts/viewport-upgrades/promotion-plan.json
```

The promotion output and manifest identify verified file/member hashes and archive hash. Root reviewed the retained manifest, successful report summaries and links. Intermediate output stays ignored and the curated directory is versionable. No producer pin was released.

Promotion verified 5 curated files, 28 raw report members and 7 retained links. The raw archive is 269654 bytes with SHA-256 `dff662b655df7df2f5762a37d8ea80bdeb0671df5457c7ee3add91baec257421`. The final local Markdown check covered 19 changed/new files and 92 local file/heading links with no failures. Ticket and whitespace checks passed. Source/runtime digests remain unchanged.
