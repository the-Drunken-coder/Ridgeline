(() => {
  const entries = [], slow = [], counts = {}, pending = [];
  const probe = window.issue123Observation = { active: false, scope: '', entries, slow, counts, pending,
    mark(event, detail = {}) { if (!event.startsWith('layer') && !event.startsWith('raf')) performance.mark('issue123.' + event); if (entries.length < 8192) entries.push({event, t: performance.now(), scope: this.scope, ...detail}); else counts.dropped = (counts.dropped || 0) + 1; } };
  const wrap = (label, original) => function (...args) {
    if (!probe.active) return Reflect.apply(original, this, args);
    const begin = performance.now(), scope = probe.scope;
    const token = {label, begin, scope}; pending.push(token);
    counts[label] = (counts[label] || 0) + 1;
    try { return Reflect.apply(original, this, args); }
    finally { const duration = performance.now() - begin; pending.pop(); if (duration > 5) {
      const entry = {label, begin, duration, scope, stack: duration > 100 ? new Error().stack : undefined};
      if (slow.length < 4096) slow.push(entry);
    } }
  };
  for (const ctor of [window.WebGLRenderingContext, window.WebGL2RenderingContext]) {
    if (!ctor) continue;
    for (const label of ['getError','getUniformLocation','getAttribLocation','getParameter','getShaderParameter','getProgramParameter','checkFramebufferStatus','readPixels','clientWaitSync','finish','flush','isContextLost']) {
      const descriptor = Object.getOwnPropertyDescriptor(ctor.prototype, label);
      if (descriptor?.value) Object.defineProperty(ctor.prototype, label, {...descriptor, value: wrap('GL.' + label, descriptor.value)});
    }
    for (const label of ['drawingBufferWidth','drawingBufferHeight']) {
      const descriptor = Object.getOwnPropertyDescriptor(ctor.prototype, label);
      if (descriptor?.get) Object.defineProperty(ctor.prototype, label, {...descriptor, get: wrap('GL.' + label, descriptor.get)});
    }
  }
  const raf = requestAnimationFrame;
  window.requestAnimationFrame = callback => raf.call(window, function (...args) {
    if (!probe.active) return Reflect.apply(callback, this, args);
    const before = probe.scope; probe.scope = 'RAF'; probe.mark('raf.entry');
    try { return wrap('RAF.callback', callback).apply(this, args); }
    finally { probe.mark('raf.return'); probe.scope = before; }
  });
  const observer = new PerformanceObserver(list => { if (probe.active) for (const e of list.getEntries()) probe.mark('longtask', {begin:e.startTime,duration:e.duration}); });
  if (PerformanceObserver.supportedEntryTypes.includes('longtask')) observer.observe({type:'longtask'});
})();
