import base from '../../playwright.packaged.config.mjs';

export default {
  ...base,
  testDir: '../../tests/packaged',
  outputDir: './focused',
  use: { ...base.use, baseURL: 'http://127.0.0.1:5296', video: 'off' },
  webServer: {
    ...base.webServer,
    cwd: '../consumer',
    command: 'pnpm exec vite preview --host 127.0.0.1 --port 5296 --strictPort',
    url: 'http://127.0.0.1:5296',
  },
};
