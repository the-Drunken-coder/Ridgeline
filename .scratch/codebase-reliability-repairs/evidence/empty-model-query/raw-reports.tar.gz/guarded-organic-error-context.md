# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: browser.spec.ts >> Reliability drawing date-line storage snapping and reload globe with terrain
- Location: tests/packaged/browser.spec.ts:25:3

# Error details

```
Error: Failed: Error: Western terrain readiness: {"liveUpdates":1,"loaded":false,"terrainLoaded":true,"elevation":100,"moving":false}
    at http://127.0.0.1:5296/assets/index-Dy3wb-LH.js:3:253826
    at async Object.run (http://127.0.0.1:5296/assets/index-Dy3wb-LH.js:142:5892)
    at async fr (http://127.0.0.1:5296/assets/index-Dy3wb-LH.js:142:6792)

expect(received).toBe(expected) // Object.is equality

Expected: "passed"
Received: "failed"
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - heading "Packaged consumer checks" [level=1] [ref=e2]
  - paragraph [ref=e3]: "Failed: Error: Western terrain readiness: {\"liveUpdates\":1,\"loaded\":false,\"terrainLoaded\":true,\"elevation\":100,\"moving\":false} at http://127.0.0.1:5296/assets/index-Dy3wb-LH.js:3:253826 at async Object.run (http://127.0.0.1:5296/assets/index-Dy3wb-LH.js:142:5892) at async fr (http://127.0.0.1:5296/assets/index-Dy3wb-LH.js:142:6792)"
  - list [ref=e4]:
    - listitem [ref=e5]: "FAIL: Reliability drawing date-line storage snapping and reload globe with terrain: Error: Western terrain readiness: {\"liveUpdates\":1,\"loaded\":false,\"terrainLoaded\":true,\"elevation\":100,\"moving\":false} Error: Western terrain readiness: {\"liveUpdates\":1,\"loaded\":false,\"terrainLoaded\":true,\"elevation\":100,\"moving\":false} at http://127.0.0.1:5296/assets/index-Dy3wb-LH.js:3:253826 at async Object.run (http://127.0.0.1:5296/assets/index-Dy3wb-LH.js:142:5892) at async fr (http://127.0.0.1:5296/assets/index-Dy3wb-LH.js:142:6792)"
```