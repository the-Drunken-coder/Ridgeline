import { resolve } from 'node:path';
import base from '../../playwright.packaged.config.mjs';
const root = resolve(import.meta.dirname, '../..');
export default {
  ...base,
  testDir: resolve(root, 'tests/packaged'),
  outputDir: resolve(root, '.artifacts/issue-123/root-playwright'),
  use: { ...base.use, baseURL: 'http://127.0.0.1:5274' },
  webServer: {
    ...base.webServer,
    command: 'pnpm exec vite preview --host 127.0.0.1 --port 5274 --strictPort',
    cwd: resolve(root, '.artifacts/consumer'),
    url: 'http://127.0.0.1:5274',
  },
};
