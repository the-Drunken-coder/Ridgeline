from pathlib import Path
import gzip,json
root=Path(__file__).parent
samples=[]
for label in ['current-instrumented','historical-instrumented','current-enhanced']:
 for p in (root/label).rglob('date-line-timeline.json'):
  obs=json.loads(p.read_text());events=obs['timeline']['entries'];provenance=json.loads((p.parent/'date-line-provenance.json').read_text())
  first=next(e for e in events if e['event']=='wait.entry');last=next(e for e in events if e['event'] in ['wait.return','wait.timeout']);subset=[e for e in events if first['now']<=e['now']<=last['now']]
  trace=json.loads(gzip.decompress((p.parent/'date-line-chrome.json.gz').read_bytes()))['traceEvents'];a=next(e for e in trace if e['name']=='pr122:wait.entry');b=next(e for e in trace if e['name'] in ['pr122:wait.return','pr122:wait.timeout'])
  spans=[]
  for e in trace:
   if e.get('pid')!=a['pid'] or e.get('tid')!=a['tid'] or e.get('name')!='GLES2::GetGLError' or not e.get('dur'):continue
   overlap=max(0,min(b['ts'],e['ts']+e['dur'])-max(a['ts'],e['ts']))
   if overlap:spans.append({'startAfterWaitMs':(e['ts']-a['ts'])/1000,'durationMs':e['dur']/1000,'overlapMs':overlap/1000,'threadCpuMs':e.get('tdur',0)/1000})
  control=[{**e,'afterWaitMs':e['now']-first['now']} for e in events if e['event'] in ['camera.entry','camera.return','interval.install.entry','interval.callback.entry','interval.callback.exit','upsert.entry','upsert.return','wait.entry','wait.return','wait.timeout','publication.updateData.entry','publication.updateData.return','publication.updateData.fulfilled','publication.updateData.rejected']]
  sample={'label':label,'timeline':str(p.resolve()),'provenance':str((p.parent/'date-line-provenance.json').resolve()),'trace':str((p.parent/'date-line-chrome.json.gz').resolve()),'status':provenance['status'],'retry':provenance['retry'],'repeatEachIndex':provenance['repeatEachIndex'],'runtimeRevision':provenance.get('runtimeRevision',provenance['source']['revision']),'waitMs':last['now']-first['now'],'rendererThreadCpuMs':(b['tts']-a['tts'])/1000,'getErrorSpans':spans,'getErrorOverlapMs':sum(e['overlapMs'] for e in spans),'events':control,'captureErrors':provenance['errors']}
  if label=='historical-instrumented':sample['runtimeRevision']='c747d780d2dcf73efed2a2857d4cb1cb48cd6121'
  samples.append(sample)
(root/'analysis.json').write_text(json.dumps(samples,indent=2))
for s in samples:print(s['label'],s['repeatEachIndex'],s['status'],'retry',s['retry'],'waitMs',round(s['waitMs'],1),'rendererCpuMs',round(s['rendererThreadCpuMs'],1),'getErrorOverlapMs',round(s['getErrorOverlapMs'],1))
